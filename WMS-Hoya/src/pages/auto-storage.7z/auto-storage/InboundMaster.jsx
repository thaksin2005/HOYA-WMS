import React, { useState, useEffect } from "react";
import { Row, Col, Button, Form, Input, Spin, Checkbox, Select } from "antd";
import { PlusOutlined, SearchOutlined } from "@ant-design/icons";
import moment from "moment";
import { useSearchParams } from "react-router-dom";
import "../../styles/autostorage.css";
import Tables from "../../components/Tables";
import DropdownActionTable from "../../components/dropdown/DropdownActionTable";
import DrawerAdd from "./components/DrawerAddInbound";
import DrawerDetail from "./components/DrawerDetail";
import axios from "axios";
import NotificationAPI from "../../components/NotificationAPI";
import calculateColumnWidth from "../../function/CalcWidth";
import ActionHeaderTable from "./components/ActionHeaderTableIRI";
import ModalImportExcel from "../../components/modal/ModalImportExcel";
import ActionFooterTable from "../../components/ActionFooterTable";

const { Option } = Select;

const InboundMaster = () => {
  const [openDrawer, setOpenDrawer] = useState(false);
  const [openDrawerDetail, setOpenDrawerDetail] = useState(false);
  const [openNotification, setOpenNotification] = useState(null);
  const [description, setDescription] = useState(null);
  const [loading, setLoading] = useState(true);
  const [dataInbound, setDataInbound] = useState([]);
  const [selectedRecord, setSelectedRecord] = useState(null);
  const [totalItem, setTotalItem] = useState(0);
  const [totalQty, setTotalQty] = useState(0);
  const [onProcessCount, setOnProcessCount] = useState(0);
  const [completedCount, setCompletedCount] = useState(0);
  const [searchText, setSearchText] = useState("");
  const [isModalImportExcelOpen, setIsModalImportExcelOpen] = useState(false);
  const [handleResetClick, setHandleResetClick] = useState(false);
  const [selectedRows, setSelectedRows] = useState([]);
  const [selectedInboundId, setSelectedInboundId] = useState(null);
  const [inboundIds, setInboundIds] = useState([]);
  const [statusCounts, setStatusCounts] = useState({
    waiting: 0,
    process: 0,
    completed: 0
  });

  const [searchParams] = useSearchParams();
  const irId = searchParams.get('irId');

  const showDrawer = () => setOpenDrawer(true);
  const onCloseDrawer = () => setOpenDrawer(false);
  const onCloseDrawerDetail = () => setOpenDrawerDetail(false);
  const [form] = Form.useForm();

  const handleSubmit = () => {
    const formValues = form.getFieldsValue();
    const formattedDate = formValues.DateCreated ? moment(formValues.DateCreated).format("YYYY-MM-DD") : null;
    console.log("Form submitted");
    console.log({ ...formValues, DateCreated: formattedDate });
    
  };

  const handleDetailClick = (record) => {
    setSelectedRecord(record);
    setOpenDrawerDetail(true);
  };

  const handleSearch = (e) => {
    setSearchText(e.target.value);
  };

  const handleInboundIdChange = (value) => {
    setSelectedInboundId(value);
  };

  const filters = (dataSource, searchText) => {
    return dataSource.filter((item) =>
      Object.values(item).some((value) =>
        value ? value.toString().toLowerCase().includes(searchText.toLowerCase()) : false
      )
    );
  };

  const columns = [
    {
      title: "✓",
      dataIndex: "checkbox",
      key: "checkbox",
      width: "3%",
      align: "center",
      fixed: "left",
      render: (text, record) => (
        <Checkbox
          checked={selectedRows.includes(record.key)}
          onChange={(e) => {
            const checked = e.target.checked;
            setSelectedRows(
              checked
                ? [...selectedRows, record.key]
                : selectedRows.filter((key) => key !== record.key)
            );
          }}
        />
      ),
    },
    {
      title: "No.",
      dataIndex: "no",
      key: "no",
      width: "4%",
      align: "center",
      fixed: "left",
    },
    {
      title: "Mold Code",
      dataIndex: "moldCode",
      key: "moldCode",
      width: calculateColumnWidth("Mold Code"),
      sorter: (a, b) => a.moldCode.localeCompare(b.moldCode),
      fixed: "left",
      align: "center",
      filters: Array.from(new Set(dataInbound.map(item => item.moldCode)))
        .filter(Boolean)
        .map(moldCode => ({
          text: moldCode,
          value: moldCode,
        })),
      onFilter: (value, record) => 
        record.moldCode ? record.moldCode.toString().includes(value) : false,
      filterSearch: true,
    },
    {
      title: "Mold Serial",
      dataIndex: "moldSerial",
      key: "moldSerial",
      width: calculateColumnWidth("Mold Serial"),
      sorter: (a, b) => a.moldSerial.localeCompare(b.moldSerial),
      fixed: "left",
      align: "center",
      filters: Array.from(new Set(dataInbound.map(item => item.moldSerial)))
        .filter(Boolean)
        .map(moldSerial => ({
          text: moldSerial,
          value: moldSerial,
        })),
      onFilter: (value, record) => 
        record.moldSerial ? record.moldSerial.toString().includes(value) : false,
      filterSearch: true,
    },
    {
      title: "Status",
      dataIndex: "InboundItemStatus",
      key: "InboundItemStatus",
      width: calculateColumnWidth("Status"),
      sorter: (a, b) => a.InboundItemStatus.localeCompare(b.InboundItemStatus),
      fixed: "left",
      align: "center",
      filters: Array.from(new Set(dataInbound.map(item => item.InboundItemStatus)))
        .filter(Boolean)
        .map(status => ({
          text: status,
          value: status,
        })),
      onFilter: (value, record) => 
        record.InboundItemStatus ? record.InboundItemStatus.toString().includes(value) : false,
      filterSearch: true,
    },
    {
      title: "Task Status",
      dataIndex: "taskStatus",
      key: "taskStatus",
      width: calculateColumnWidth("Task Status"),
      sorter: (a, b) => a.taskStatus.localeCompare(b.taskStatus),
      fixed: "left",
      align: "center",
      filters: Array.from(new Set(dataInbound.map(item => item.taskStatus)))
        .filter(Boolean)
        .map(status => ({
          text: status,
          value: status,
        })),
      onFilter: (value, record) => 
        record.taskStatus ? record.taskStatus.toString().includes(value) : false,
      filterSearch: true,
    },
    {
      title: "Tray Position",
      dataIndex: "trayposiyion",
      key: "trayposiyion",
      width: calculateColumnWidth("Tray Position"),
      sorter: (a, b) => a.trayposiyion.localeCompare(b.trayposiyion),
      fixed: "left",
      align: "center",
      filters: Array.from(new Set(dataInbound.map(item => item.trayposiyion)))
        .filter(Boolean)
        .map(position => ({
          text: position,
          value: position,
        })),
      onFilter: (value, record) => 
        record.trayposiyion ? record.trayposiyion.toString().includes(value) : false,
      filterSearch: true,
    },
    {
      title: "Total Location",
      dataIndex: "totallocation",
      key: "totallocation",
      width: calculateColumnWidth("Total Location"),
      sorter: (a, b) => a.totallocation.localeCompare(b.totallocation),
      fixed: "left",
      align: "center",
      filters: Array.from(new Set(dataInbound.map(item => item.totallocation)))
        .filter(Boolean)
        .map(location => ({
          text: location,
          value: location,
        })),
      onFilter: (value, record) => 
        record.totallocation ? record.totallocation.toString().includes(value) : false,
      filterSearch: true,
    },
    {
      title: "More",
      dataIndex: "more",
      key: "more",
      render: (text, record) => (
        <DropdownActionTable onDetailClick={handleDetailClick} record={record} />
      ),
      width: "4%",
      align: "center",
      fixed: "right",
    },
  ];

  const getInbound = async () => {
    try {
      const response = await axios.get(
        "http://192.168.0.122:1234/api/InboundItempDetail-requests"
      );

      const data = response.data.map((item, index) => ({
        id: item.IRI_IDInboundRequestItem,
        key: item.IRI_IDInboundRequestItem,
        no: (index + 1).toString(),
        InboundNo: item.InboundNumber,
        moldCode: item.MoldCode,
        moldSerial: item.MoldSerial,
        InboundItemStatus: item.InboundItemStatus,
        taskStatus: item.TaskStatus,
        trayposiyion: item.TrayPosition,
        totalLocation: item.ToLocation,
        irId: item.IR_IDInboundRequest,
        more: <DropdownActionTable onDetailClick={handleDetailClick} record={item} />,
      }));

      const filteredData = irId ? data.filter(item => item.irId === irId) : data;

      const counts = {
        waiting: filteredData.filter(item => item.InboundItemStatus === "Waiting").length,
        process: filteredData.filter(item => item.InboundItemStatus === "Process").length,
        completed: filteredData.filter(item => item.InboundItemStatus === "Completed").length
      };

      setStatusCounts(counts);
      setTotalItem(filteredData.length);
      setTotalQty(filteredData.reduce((acc, item) => acc + item.qty, 0));

      const onProcess = filteredData.filter((item) => item.status === "On Process").length;
      const completed = filteredData.filter((item) => item.status === "Completed").length;

      setOnProcessCount(onProcess);
      setCompletedCount(completed);

      setDataInbound(filteredData);

      const ids = filteredData.map((item) => item.id);
      setInboundIds(ids);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    getInbound();
  }, [irId]);

  useEffect(() => {
    const interval = setInterval(() => {
      if (dataInbound.length > 0) {
        const checkNewData = async () => {
          const response = await axios.get("api/TaskInboundDetail-requests");
          const newData = response.data.filter(
            (item) => !dataInbound.some((data) => data.key === item.TI_ID)
          );

          if (newData.length > 0) {
            getInbound();
            setOpenNotification("info");
            setDescription("New data is added " + newData.length + " record");
          }
        };
        checkNewData();
      }
    }, 2000);

    return () => clearInterval(interval);
  }, [dataInbound]);

  useEffect(() => {
    setLoading(dataInbound.length === 0);
  }, [dataInbound]);

  const filteredData = filters(dataInbound, searchText);

  const filteredDataById = selectedInboundId
    ? filteredData.filter((item) => item.id === selectedInboundId)
    : filteredData;

  return (
    <>
      <div className="table-container">
        <div className="table-header">
          <Row 
            style={{ 
              marginBottom: "16px",
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center"
            }}
          >
            <Col span={8}>
              <Input.Search
                placeholder="Search"
                allowClear
                enterButton={<SearchOutlined />}
                onSearch={handleSearch}
                onChange={(e) => handleSearch(e)}
                style={{ width: 400 }}
              />
            </Col>
            <Col>
              <Row gutter={16}>
                <Col>
                  <div className="detail-input" style={{ textAlign: 'center', width: 100 }}>
                    <div>Item:</div>
                    <strong>{totalItem}</strong>
                  </div>
                </Col>
                <Col>
                  <div className="detail-input" style={{ textAlign: 'center', width: 100  }}>
                    <div>Waiting:</div>
                    <strong>{statusCounts.waiting}</strong>
                  </div>
                </Col>
                <Col>
                  <div className="detail-input" style={{ textAlign: 'center', width: 100  }}>
                    <div>Process:</div>
                    <strong>{statusCounts.process}</strong>
                  </div>
                </Col>
                <Col>
                  <div className="detail-input" style={{ textAlign: 'center' , width: 120 }}>
                    <div>Completed:</div>
                    <strong>{statusCounts.completed}</strong>
                  </div>
                </Col>
              </Row>
            </Col>
          </Row>
        </div>

        <section style={{ marginTop: "10px" }}>
          <Spin spinning={loading}>
            <Tables
              columns={columns}
              dataSource={filteredDataById}
              bordered
              scrollY={0.5}
              scrollX={"max-content"}
              maxHeight={"480px"}
            />
          </Spin>
        </section>

        <div className="action-footer-table">
        </div>
      </div>

      <section>
        <NotificationAPI openNotification={openNotification} description={description} />
        <DrawerAdd open={openDrawer} onClose={onCloseDrawer} />
        <DrawerDetail open={openDrawerDetail} onClose={onCloseDrawerDetail} record={selectedRecord} />
      </section>

      <ModalImportExcel isModalOpen={isModalImportExcelOpen} setIsModalOpen={setIsModalImportExcelOpen} />

      <style jsx>{`
        .status-count {
          text-align: center;
          padding: 8px;
          background: white;
          border-radius: 4px;
          box-shadow: 0 2px 0 rgba(0,0,0,0.05);
        }
        .status-count span {
          display: block;
          margin-bottom: 4px;
          color: rgba(0,0,0,0.65);
        }
        .status-count strong {
          font-size: 20px;
          font-weight: 600;
        }
      `}</style>
    </>
  );
};

export default InboundMaster;