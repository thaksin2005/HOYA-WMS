import React from "react";

const OvenMonitor = () => {
  return <div>Cycle Count </div>;
};

export default OvenMonitor ;
