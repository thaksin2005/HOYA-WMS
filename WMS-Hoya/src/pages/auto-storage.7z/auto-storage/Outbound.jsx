import React, { useState, useEffect } from "react";
import { Row, Col, Button, Form, Input, Spin, Checkbox, Modal, Upload } from "antd";
import { PlusOutlined, CheckOutlined, ExclamationCircleOutlined, UploadOutlined } from "@ant-design/icons";
import moment from "moment";
import "../../styles/autostorage.css";
import Tables from "../../components/Tables";
import DropdownActionTable from "../../components/dropdown/DropdownActionTable";
import DrawerAdd from "./components/DrawerAddInbound";
import DrawerDetail from "./components/DrawerDetail";
import axios from "axios";
import NotificationAPI from "../../components/NotificationAPI";
import calculateColumnWidth from "../../function/CalcWidth";
import ActionHeaderTableIR from "./components/ActionHeaderTableIR";
import ModalImportExcel from "../../components/modal/ModalImportExcel";
import ActionFooterTable from "../../components/ActionFooterTable";
import { Link } from "react-router-dom";
import { Space } from "antd";

const Outbound = () => {
  const [openDrawer, setOpenDrawer] = useState(false);
  const [openDrawerDetail, setOpenDrawerDetail] = useState(false);
  const [openNotification, setOpenNotification] = useState(null);
  const [description, setDescription] = useState(null);
  const [loading, setLoading] = useState(true);
  const [dataInbound, setDataInbound] = useState([]);
  const [selectedRecord, setSelectedRecord] = useState(null);
  const [totalItem, setTotalItem] = useState(0);
  const [totalQty, setTotalQty] = useState(0);
  const [onProcessCount, setOnProcessCount] = useState(0);
  const [completedCount, setCompletedCount] = useState(0);
  const [searchText, setSearchText] = useState("");
  const [isModalImportExcelOpen, setIsModalImportExcelOpen] = useState(false);
  const [handleResetClick, setHandleResetClick] = useState(false);
  const [selectedRows, setSelectedRows] = useState([]);
  const [confirmLoading, setConfirmLoading] = useState(false);
  const { confirm } = Modal;
  const [totalOnProcess, setTotalOnProcess] = useState(0);
  const [totalCompleted, setTotalCompleted] = useState(0);
  const [uploading, setUploading] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);
  const [isImportModalVisible, setIsImportModalVisible] = useState(false);

  const showDrawer = () => setOpenDrawer(true);
  const onCloseDrawer = () => setOpenDrawer(false);
  const onCloseDrawerDetail = () => setOpenDrawerDetail(false);
  const [form] = Form.useForm();

  const handleSubmit = () => {
    // ...
  };

  const handleDetailClick = (record) => {
    // ...
  };

  const filters = (dataSource, searchText) => {
    // ...
  };

  const handleConfirm = (record) => {
    confirm({
      title: 'Confirm Action',
      icon: <ExclamationCircleOutlined style={{ color: '#ff4d4f' }} />,
      content: `Are you sure you want to confirm Outbound No: ${record.OR_Number}?`,
      okText: 'Confirm',
      cancelText: 'Cancel',
      okButtonProps: {
        danger: true
      },
      onOk: async () => {
        try {
          const response = await axios.put(
            'http://192.168.0.122:1234/api/confirm-outbound',
            {
              OR_IDOutboundRequest: record.OR_IDOutboundRequest,
              Status: 'Confirmed'
            }
          );

          if (response.status === 200) {
            setOpenNotification('success');
            setDescription(`Successfully confirmed Outbound No: ${record.OR_Number}`);
            // Refresh data
            getInbound();
          }
        } catch (error) {
          console.error('Error confirming outbound:', error);
          setOpenNotification('error');
          setDescription(`Failed to confirm Outbound No: ${record.OR_Number}`);
        }
      },
      onCancel() {
        console.log('Cancel');
      },
    });
  };

  const showImportModal = () => {
    setIsImportModalVisible(true);
  };

  const handleImportCancel = () => {
    setSelectedFile(null);
    setIsImportModalVisible(false);
  };

  const handleUpload = async () => {
    if (!selectedFile) {
      setOpenNotification('error');
      setDescription('Please select a file first!');
      return;
    }

    try {
      setUploading(true);
      const formData = new FormData();
      formData.append('file', selectedFile);

      const response = await axios.post(
        'http://192.168.0.122:3333/api/import-outbound-csv',
        formData,
        {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        }
      );

      if (response.status === 200) {
        setOpenNotification('success');
        setDescription('Successfully imported CSV file');
        getInbound();
        setIsImportModalVisible(false);
        setSelectedFile(null);
      }
    } catch (error) {
      console.error('Error uploading CSV:', error);
      setOpenNotification('error');
      setDescription('Failed to import CSV file');
    } finally {
      setUploading(false);
    }
  };

  const columns = [
    {
      title: "✓",
      dataIndex: "checkbox",
      key: "checkbox",
      width: "3%",
      align: "center",
      fixed: "left",
      render: (text, record) => (
        <Checkbox
          checked={selectedRows.includes(record.key)}
          onChange={(e) => {
            const checked = e.target.checked;
            setSelectedRows(
              checked
                ? [...selectedRows, record.key]
                : selectedRows.filter((key) => key !== record.key)
            );
          }}
        />
      ),
    },
    {
      title: "No.",
      dataIndex: "no",
      key: "no",
      width: "3%",
      align: "center",
      fixed: "left",
    },
    {
      title: "Outbound No",
      dataIndex: "OR_Number",
      key: "OR_Number",
      width: calculateColumnWidth("Outbound No"),
      sorter: (a, b) => a.OR_Number.localeCompare(b.OR_Number),
      fixed: "left",
      align: "center",
      sticky: true,
      render: (text, record) => {
        console.log("Rendering link for record:", record);
        return (
          <Link
            to={`/auto-storage/outbound-master?orId=${record.OR_IDOutboundRequest}`}
            style={{ color: '#1890ff', textDecoration: 'underline' }}
          >
            {text || record.OR_Number}
          </Link>
        );
      },
    },
    {
      title: "Job Number",
      dataIndex: "OR_JobNumber",
      key: "OR_JobNumber",
      width: calculateColumnWidth("Job Number"),
      sorter: (a, b) => a.OR_JobNumber - b.OR_JobNumber,
      fixed: "left",
      align: "center",
    },
    {
      title: "Status",
      dataIndex: "OR_Status",
      key: "OR_Status",
      width: calculateColumnWidth("Status"),
      sorter: (a, b) => a.OR_Status.localeCompare(b.OR_Status),
      align: "center",
      render: (text, record) => (
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span>{text}</span>
          {text === 'New' && (
            <Button
              type="primary"
              icon={<CheckOutlined />}
              size="small"
              loading={confirmLoading}
              onClick={() => handleConfirm(record)}
              style={{ marginLeft: 8 }}
            >
              Confirm
            </Button>
          )}
        </div>
      ),
    },
    {
      title: "Factory Name",
      dataIndex: "F_Name",
      key: "F_Name",
      width: calculateColumnWidth("Factory Name"),
      sorter: (a, b) => a.F_Name.localeCompare(b.F_Name),
      align: "center",
    },
    {
      title: "Warehouse Name",
      dataIndex: "W_Name",
      key: "W_Name",
      width: calculateColumnWidth("Warehouse Name"),
      sorter: (a, b) => a.W_Name.localeCompare(b.W_Name),
      align: "center",
    },
    {
      title: "Plant Name",
      dataIndex: "P_Name",
      key: "P_Name",
      width: calculateColumnWidth("Plant Name"),
      sorter: (a, b) => a.P_Name.localeCompare(b.P_Name),
      align: "center",
    },
    {
      title: "Interface File",
      dataIndex: "OR_InterfaceFile",
      key: "OR_InterfaceFile",
      width: calculateColumnWidth("Interface File"),
      align: "center",
    },
    {
      title: "User Full Name",
      dataIndex: "UA_Fullname",
      key: "UA_Fullname",
      width: calculateColumnWidth("User Full Name"),
      sorter: (a, b) => a.UA_Fullname.localeCompare(b.UA_Fullname),
      align: "center",
    },
    {
      title: "Record On",
      dataIndex: "OR_RecordOn",
      key: "OR_RecordOn",
      width: calculateColumnWidth("Record On"),
      sorter: (a, b) => a.OR_RecordOn.localeCompare(b.OR_RecordOn),
      align: "center",
    },
    {
      title: "More",
      dataIndex: "more",
      key: "more",
      render: (text, record) => (
        <DropdownActionTable onDetailClick={handleDetailClick} record={record} />
      ),
      width: "60px",
      align: "center",
      fixed: "right",
    },
  ];

  const getInbound = async () => {
    try {
      const response = await axios.get(
        "http://192.168.0.122:1234/api/OutboundDetail-requests"
      );

      console.log("API Response:", response.data);

      const data = response.data.map((item, index) => ({
        key: item.OR_IDOutboundRequest,
        no: (index + 1).toString(),
        OR_IDOutboundRequest: item.OR_IDOutboundRequest,
        OR_Number: item.OR_Number || "N/A",
        OR_JobNumber: item.OR_JobNumber || "N/A",
        OR_Status: item.OR_Status || "N/A",
        F_Name: item.F_Name || "N/A",
        W_Name: item.W_Name || "N/A",
        P_Name: item.P_Name || "N/A",
        OR_InterfaceFile: item.OR_InterfaceFile || "N/A",
        UA_Code: item.UA_Code || "N/A",
        UA_Fullname: item.UA_Fullname || "N/A",
        OR_RecordOn: item.OR_RecordOn ? moment(item.OR_RecordOn).format("YYYY-MM-DD HH:mm:ss") : "N/A"
      }));

      console.log("Mapped Data:", data);

      setDataInbound(data);
      setTotalItem(data.length);
      
      const onProcess = data.filter((item) => item.OR_Status === "Process").length;
      const completed = data.filter((item) => item.OR_Status === "Completed").length;
      const newStatus = data.filter((item) => item.OR_Status === "New").length;

      setOnProcessCount(onProcess);
      setCompletedCount(completed);
      setTotalOnProcess(onProcess);
      setTotalCompleted(completed);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    getInbound();
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      if (dataInbound.length > 0) {
        const checkNewData = async () => {
          const response = await axios.get("api/OutboundDetail-requests");
          const newData = response.data.filter(
            (item) => !dataInbound.some((data) => data.key === item.TI_ID)
          );

          if (newData.length > 0) {
            getInbound();
            setOpenNotification("info");
            setDescription("New data is added " + newData.length + " record");
          }
        };
        checkNewData();
      }
    }, 2000);

    return () => clearInterval(interval);
  }, [dataInbound]);

  useEffect(() => {
    setLoading(dataInbound.length === 0);
  }, [dataInbound]);

  const filteredData = dataInbound.filter((item) =>
    Object.values(item).some((value) =>
      value ? value.toString().toLowerCase().includes(searchText.toLowerCase()) : false
    )
  );

  return (
    <>
      <div className="table-container">
        <div className="table-header">
          <Row style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <Col>
              <Space size="middle">
                <Button
                  type="primary"
                  icon={<PlusOutlined />}
                  onClick={showDrawer}
                >
                  Add New
                </Button>
                
                <Button
                  type="primary"
                  icon={<UploadOutlined />}
                  onClick={showImportModal}
                  style={{ 
                    backgroundColor: '#52c41a',
                    borderColor: '#52c41a'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.backgroundColor = '#389e0d';
                    e.currentTarget.style.borderColor = '#389e0d';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.backgroundColor = '#52c41a';
                    e.currentTarget.style.borderColor = '#52c41a';
                  }}
                >
                  Import CSV
                </Button>
              </Space>
            </Col>

            <Col>
              <Row gutter={16}>
                <Col>
                  <div className="detail-input" style={{ textAlign: 'center' }}>
                    <div>Item:</div>
                    <strong>{totalItem}</strong>
                  </div>
                </Col>

                <Col>
                  <div className="detail-input" style={{ textAlign: 'center' }}>
                    <div>On Process:</div>
                    <strong>{onProcessCount}</strong>
                  </div>
                </Col>

                <Col>
                  <div className="detail-input" style={{ textAlign: 'center' }}>
                    <div>Completed:</div>
                    <strong>{completedCount}</strong>
                  </div>
                </Col>
              </Row>
            </Col>
          </Row>
        </div>
        
        <section style={{ marginTop: "10px" }}>
          <Spin spinning={loading}>
            <Tables
              columns={columns}
              dataSource={filteredData}
              bordered
              scrollY={0.5}
              scrollX={"max-content"}
              maxHeight={"480px"}
            />
          </Spin>
        </section>

        <div className="action-footer-table">
          {/* <ActionFooterTable handleReset={() => setHandleResetClick(true)} /> */}
        </div>
      </div>

      <section>
        <NotificationAPI openNotification={openNotification} description={description} />
        <DrawerAdd open={openDrawer} onClose={onCloseDrawer} />
        <DrawerDetail open={openDrawerDetail} onClose={onCloseDrawerDetail} record={selectedRecord} />
      </section>

      <ModalImportExcel isModalOpen={isModalImportExcelOpen} setIsModalOpen={setIsModalImportExcelOpen} />

      <Modal
        title="Import CSV File"
        open={isImportModalVisible}
        onCancel={handleImportCancel}
        footer={[
          <Button key="cancel" onClick={handleImportCancel}>
            Cancel
          </Button>,
          <Button
            key="import"
            type="primary"
            loading={uploading}
            onClick={handleUpload}
            disabled={!selectedFile}
            style={{ 
              backgroundColor: '#52c41a',
              borderColor: '#52c41a'
            }}
          >
            Import
          </Button>
        ]}
      >
        <p style={{ marginBottom: '16px' }}>Please select a CSV file to import:</p>
        <Upload
          accept=".csv"
          beforeUpload={(file) => {
            const isCSV = file.type === 'text/csv' || file.name.endsWith('.csv');
            if (!isCSV) {
              setOpenNotification('error');
              setDescription('You can only upload CSV files!');
              return Upload.LIST_IGNORE;
            }
            setSelectedFile(file);
            return false;
          }}
          onRemove={() => setSelectedFile(null)}
          fileList={selectedFile ? [selectedFile] : []}
        >
          <Button icon={<UploadOutlined />}>Select File</Button>
        </Upload>
      </Modal>
    </>
  );
};

export default Outbound;
