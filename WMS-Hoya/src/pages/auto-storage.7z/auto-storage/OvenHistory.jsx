import React from "react";

const OvenHistory = () => {
  return <div>Cycle Count </div>;
};

export default OvenHistory ;
