import React from "react";

const OvenTranfer = () => {
  return <div>Cycle Count </div>;
};

export default OvenTranfer ;
