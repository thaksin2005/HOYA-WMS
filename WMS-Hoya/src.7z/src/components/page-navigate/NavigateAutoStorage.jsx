import React from "react";
import {
  Gauge,
  ArrowBigDownDash,
  ArrowBigUpDash,
  RefreshCcwDot,
  FileSliders,
  Grid2x2Plus,
} from "lucide-react";

export const menuAutoStorage = (navigate) => [
  {
    key: "1",
    icon: <Gauge size={16} />,
    label: "Monitoring",
    onClick: () => navigate("/auto-storage"),
  },
  {
    key: "2",
    icon: <ArrowBigDownDash size={16} />,
    label: "Inbound",
    onClick: () => navigate("/auto-storage/inbound"),
  },
  {
    key: "2-1",
    // icon: <ArrowBigDownDash size={16} />,
    // label: "Inbound Master",
    // onClick: () => navigate("/auto-storage/inbound-master"),
  },
  {
    key: "3",
    icon: <ArrowBigUpDash size={16} />,
    label: "Outbound",
    onClick: () => navigate("/auto-storage/outbound"),
  },
  // {
  //   key: "3-1",
  //   icon: <ArrowBigUpDash size={16} />,
  //   label: "Outbound Master",
  //   onClick: () => navigate("/auto-storage/outbound-master"),
  // },
  {
    key: "4",
    icon: <RefreshCcwDot size={16} />,
    label: "Cycle Count",
    onClick: () => navigate("/auto-storage/cycle-count"),
  },
  {
    key: "5",
    icon: <FileSliders size={16} />,
    label: "Inspection Mold",
    onClick: () => navigate("/auto-storage/inspection-mold"),
  }
];

export const pathToKeyAutoStorage = {
  "/auto-storage": "1",
  "/auto-storage/inbound": "2",
  "/auto-storage/inbound-master": "2",
  "/auto-storage/outbound": "3",
  "/auto-storage/outbound-master": "3",
  "/auto-storage/cycle-count": "4",
  "/auto-storage/inspection-mold": "5",
};
