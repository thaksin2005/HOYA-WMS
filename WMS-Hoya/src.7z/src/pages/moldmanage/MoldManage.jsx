import React from "react";

const MoldManage = () => {
  return <div>Mold Management</div>;
};

export default MoldManage;
