import React from "react";

const ProductPlan = () => {
  return <div>Production Plan</div>;
};

export default ProductPlan;
