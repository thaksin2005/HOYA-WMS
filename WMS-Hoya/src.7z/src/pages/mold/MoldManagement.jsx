import React from "react";

const MoldManagement = () => {
  return <div>MoldManagement</div>;
};

export default MoldManagement;
