import React from "react";

const MatchMold = () => {
  return <div>MatchMold</div>;
};

export default MatchMold;
