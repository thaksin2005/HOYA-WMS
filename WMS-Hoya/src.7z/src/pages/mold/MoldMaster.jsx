import { useState, useEffect } from "react";
import Tables from "../../components/Tables";
import DropdownActionTable from "../../components/dropdown/DropdownActionTable";
import { Button, Input } from "antd";
import { Plus, Upload } from "lucide-react";
import ModalAddMoldMaster from "../../components/modal/ModalAddMoldMaster";
import ModalImportMoldMaster from "../../components/modal/ModalImportMoldMaster";
import "../../styles/global.css";
import { Spin } from "antd";
import DrawerDetailMoldMaster from "./components/DrawerDetailMoldMaster";
import NotificationAPI from "../../components/NotificationAPI";
import calculateColumnWidth from "../../function/CalcWidth";
import filters from "../../function/FilterTable";


const MoldMaster = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false); // State สำหรับ Import Modal
  const [openNotification, setOpenNotification] = useState(false);
  const [description, setDescription] = useState("");
  const [searchText, setSearchText] = useState("");
  const [moldMasterData, setMoldMasterData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [openDrawerDetail, setOpenDrawerDetail] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState(null);

  const onCloseDrawerDetail = () => {
    setOpenDrawerDetail(false);
  };

  const showModal = () => setIsModalOpen(true);
  const showImportModal = () => setIsImportModalOpen(true);

  const handleSearch = (e) => setSearchText(e.target.value);
  const handleDetailClick = (record) => {
    setSelectedRecord(record);
    setOpenDrawerDetail(true);
  };

  const columns = [
    {
      title: "No.",
      width: "60px",
      dataIndex: "MM_ID",
      align: "center",
      fixed: "left",
    },
    {
      title: "Up/Low Name",
      dataIndex: "MM_UpLowName",
      align: "center",
      width: calculateColumnWidth("Up/Low Name"),
      fixed: "left",
    },
    {
      title: "Mold Code",
      dataIndex: "MM_MoldCode",
      align: "center",
      width: calculateColumnWidth("Mold Code"),
      fixed: "left",
    },
    {
      title: "Type",
      dataIndex: "MM_TypeShortName",
      align: "center",
      width: calculateColumnWidth("Type"),
    },
    {
      title: "Lens Name",
      dataIndex: "MM_LensName",
      width: calculateColumnWidth("Lens Name"),
    },
    {
      title: "Min Stock",
      dataIndex: "MM_MinStock",
      align: "center",
      width: calculateColumnWidth("Min Stock"),
    },
    {
      title: "Max Stock",
      dataIndex: "MM_MaxStock",
      align: "center",
      width: calculateColumnWidth("Max Stock"),
    },
    {
      title: "Plant Number",
      dataIndex: "MM_PlantNumber",
      align: "center",
      width: calculateColumnWidth("Plant Number"),
    },
    {
      title: "Item Number",
      dataIndex: "MM_ItemNumber",
      align: "center",
      width: calculateColumnWidth("Item Number"),
    },
    {
      title: "Class",
      dataIndex: "MM_Class",
      align: "center",
      width: calculateColumnWidth("Class"),
    },
    {
      title: "Update By",
      dataIndex: "UA_CodeUpdateBy",
      align: "center",
      width: calculateColumnWidth("Update By"),
    },
    {
      title: "Updated On",
      dataIndex: "MM_UpdateOn",
      align: "center",
      width: calculateColumnWidth("Updated On"),
    },
    {
      title: "More",
      dataIndex: "more",
      width: "60px",
      render: (text, record) => (
        <DropdownActionTable
          onDetailClick={handleDetailClick}
          record={record}
        />
      ),
      align: "center",
      fixed: "right",
    },
  ];

  // Data ที่นำเข้ามา
  const data = [
    {
      MM_ID: 1,
      MM_UpLowName: "UPP",
      MM_MoldCode: "30879",
      MM_TypeShortName: "SPH",
      MM_LensName: "7ID3275N",
      MM_MaxStock: 5000,
      MM_MinStock: 0,
      MM_PlantNumber: "62000200000030800",
      MM_ItemNumber: null,
      MM_Class: null,
      UA_CodeUpdateBy: null,
      MM_UpdateOn: null,
    },
    {
      MM_ID: 2,
      MM_UpLowName: "LOW",
      MM_MoldCode: "510062",
      MM_TypeShortName: "SPH",
      MM_LensName: "UYS87 5",
      MM_MaxStock: 5000,
      MM_MinStock: 0,
      MM_PlantNumber: "62000200000510000",
      MM_ItemNumber: "A",
      MM_Class: null,
      UA_CodeUpdateBy: null,
      MM_UpdateOn: null,
    },
    {
      MM_ID: 3,
      MM_UpLowName: "LOW",
      MM_MoldCode: "510233",
      MM_TypeShortName: "SPH",
      MM_LensName: "525K 5",
      MM_MaxStock: 5000,
      MM_MinStock: 0,
      MM_PlantNumber: "62000200000510200",
      MM_ItemNumber: null,
      MM_Class: null,
      UA_CodeUpdateBy: null,
      MM_UpdateOn: null,
    },
    {
      MM_ID: 4,
      MM_UpLowName: "LOW",
      MM_MoldCode: "510234",
      MM_TypeShortName: "SPH",
      MM_LensName: "LKS102 5",
      MM_MaxStock: 5000,
      MM_MinStock: 0,
      MM_PlantNumber: "62000200000510200",
      MM_ItemNumber: null,
      MM_Class: null,
      UA_CodeUpdateBy: null,
      MM_UpdateOn: null,
    },
    {
      MM_ID: 5,
      MM_UpLowName: "UPP",
      MM_MoldCode: "30880",
      MM_TypeShortName: "SPH",
      MM_LensName: "7ID3276N",
      MM_MaxStock: 5100,
      MM_MinStock: 100,
      MM_PlantNumber: "62000200000030801",
      MM_ItemNumber: null,
      MM_Class: null,
      UA_CodeUpdateBy: null,
      MM_UpdateOn: null,
    },
    {
      MM_ID: 6,
      MM_UpLowName: "LOW",
      MM_MoldCode: "510063",
      MM_TypeShortName: "SPH",
      MM_LensName: "UYS88 5",
      MM_MaxStock: 5200,
      MM_MinStock: 100,
      MM_PlantNumber: "62000200000510001",
      MM_ItemNumber: "B",
      MM_Class: null,
      UA_CodeUpdateBy: null,
      MM_UpdateOn: null,
    },
    {
      MM_ID: 7,
      MM_UpLowName: "LOW",
      MM_MoldCode: "510235",
      MM_TypeShortName: "SPH",
      MM_LensName: "525K 6",
      MM_MaxStock: 5300,
      MM_MinStock: 200,
      MM_PlantNumber: "62000200000510201",
      MM_ItemNumber: null,
      MM_Class: null,
      UA_CodeUpdateBy: null,
      MM_UpdateOn: null,
    },
    {
      MM_ID: 8,
      MM_UpLowName: "UPP",
      MM_MoldCode: "30881",
      MM_TypeShortName: "SPH",
      MM_LensName: "7ID3277N",
      MM_MaxStock: 5400,
      MM_MinStock: 300,
      MM_PlantNumber: "62000200000030802",
      MM_ItemNumber: null,
      MM_Class: null,
      UA_CodeUpdateBy: null,
      MM_UpdateOn: null,
    },
    {
      MM_ID: 9,
      MM_UpLowName: "LOW",
      MM_MoldCode: "510064",
      MM_TypeShortName: "SPH",
      MM_LensName: "UYS89 5",
      MM_MaxStock: 5500,
      MM_MinStock: 300,
      MM_PlantNumber: "62000200000510002",
      MM_ItemNumber: "C",
      MM_Class: null,
      UA_CodeUpdateBy: null,
      MM_UpdateOn: null,
    },
    {
      MM_ID: 10,
      MM_UpLowName: "LOW",
      MM_MoldCode: "510236",
      MM_TypeShortName: "SPH",
      MM_LensName: "525K 7",
      MM_MaxStock: 5600,
      MM_MinStock: 400,
      MM_PlantNumber: "62000200000510202",
      MM_ItemNumber: null,
      MM_Class: null,
      UA_CodeUpdateBy: null,
      MM_UpdateOn: null,
    },
    {
      MM_ID: 11,
      MM_UpLowName: "UPP",
      MM_MoldCode: "30882",
      MM_TypeShortName: "SPH",
      MM_LensName: "7ID3278N",
      MM_MaxStock: 5700,
      MM_MinStock: 500,
      MM_PlantNumber: "62000200000030803",
      MM_ItemNumber: null,
      MM_Class: null,
      UA_CodeUpdateBy: null,
      MM_UpdateOn: null,
    },
    {
      MM_ID: 12,
      MM_UpLowName: "LOW",
      MM_MoldCode: "510065",
      MM_TypeShortName: "SPH",
      MM_LensName: "UYS90 5",
      MM_MaxStock: 5800,
      MM_MinStock: 500,
      MM_PlantNumber: "62000200000510003",
      MM_ItemNumber: "D",
      MM_Class: null,
      UA_CodeUpdateBy: null,
      MM_UpdateOn: null,
    },
    {
      MM_ID: 13,
      MM_UpLowName: "LOW",
      MM_MoldCode: "510237",
      MM_TypeShortName: "SPH",
      MM_LensName: "525K 8",
      MM_MaxStock: 5900,
      MM_MinStock: 600,
      MM_PlantNumber: "62000200000510203",
      MM_ItemNumber: null,
      MM_Class: null,
      UA_CodeUpdateBy: null,
      MM_UpdateOn: null,
    },
    {
      MM_ID: 14,
      MM_UpLowName: "UPP",
      MM_MoldCode: "30883",
      MM_TypeShortName: "SPH",
      MM_LensName: "7ID3279N",
      MM_MaxStock: 6000,
      MM_MinStock: 700,
      MM_PlantNumber: "62000200000030804",
      MM_ItemNumber: null,
      MM_Class: null,
      UA_CodeUpdateBy: null,
      MM_UpdateOn: null,
    },
    {
      MM_ID: 15,
      MM_UpLowName: "LOW",
      MM_MoldCode: "510066",
      MM_TypeShortName: "SPH",
      MM_LensName: "UYS91 5",
      MM_MaxStock: 6100,
      MM_MinStock: 700,
      MM_PlantNumber: "62000200000510004",
      MM_ItemNumber: "E",
      MM_Class: null,
      UA_CodeUpdateBy: null,
      MM_UpdateOn: null,
    },
    {
      MM_ID: 16,
      MM_UpLowName: "LOW",
      MM_MoldCode: "510238",
      MM_TypeShortName: "SPH",
      MM_LensName: "525K 9",
      MM_MaxStock: 6200,
      MM_MinStock: 800,
      MM_PlantNumber: "62000200000510204",
      MM_ItemNumber: null,
      MM_Class: null,
      UA_CodeUpdateBy: null,
      MM_UpdateOn: null,
    },
    {
      MM_ID: 17,
      MM_UpLowName: "UPP",
      MM_MoldCode: "30884",
      MM_TypeShortName: "SPH",
      MM_LensName: "7ID3280N",
      MM_MaxStock: 6300,
      MM_MinStock: 900,
      MM_PlantNumber: "62000200000030805",
      MM_ItemNumber: null,
      MM_Class: null,
      UA_CodeUpdateBy: null,
      MM_UpdateOn: null,
    },
    {
      MM_ID: 18,
      MM_UpLowName: "LOW",
      MM_MoldCode: "510067",
      MM_TypeShortName: "SPH",
      MM_LensName: "UYS92 5",
      MM_MaxStock: 6400,
      MM_MinStock: 900,
      MM_PlantNumber: "62000200000510005",
      MM_ItemNumber: "F",
      MM_Class: null,
      UA_CodeUpdateBy: null,
      MM_UpdateOn: null,
    },
    {
      MM_ID: 19,
      MM_UpLowName: "LOW",
      MM_MoldCode: "510239",
      MM_TypeShortName: "SPH",
      MM_LensName: "525K 10",
      MM_MaxStock: 6500,
      MM_MinStock: 1000,
      MM_PlantNumber: "62000200000510205",
      MM_ItemNumber: null,
      MM_Class: null,
      UA_CodeUpdateBy: null,
      MM_UpdateOn: null,
      
    },
    {
      MM_ID: 20,
      MM_UpLowName: "UPP",
      MM_MoldCode: "30885",
      MM_TypeShortName: "SPH",
      MM_LensName: "7ID3281N",
      MM_MaxStock: 6600,
      MM_MinStock: 1100,
      MM_PlantNumber: "62000200000030806",
      MM_ItemNumber: null,
      MM_Class: null,
      UA_CodeUpdateBy: null,
      MM_UpdateOn: null,
    },
    {
      MM_ID: 21,
      MM_UpLowName: "LOW",
      MM_MoldCode: "510068",
      MM_TypeShortName: "SPH",
      MM_LensName: "UYS93 5",
      MM_MaxStock: 6700,
      MM_MinStock: 1100,
      MM_PlantNumber: "62000200000510006",
      MM_ItemNumber: "G",
      MM_Class: null,
      UA_CodeUpdateBy: null,
      MM_UpdateOn: null,
    },
    {
      MM_ID: 22,
      MM_UpLowName: "LOW",
      MM_MoldCode: "510240",
      MM_TypeShortName: "SPH",
      MM_LensName: "525K 11",
      MM_MaxStock: 6800,
      MM_MinStock: 1200,
      MM_PlantNumber: "62000200000510206",
      MM_ItemNumber: null,
      MM_Class: null,
      UA_CodeUpdateBy: null,
      MM_UpdateOn: null,
    },
    {
      MM_ID: 23,
      MM_UpLowName: "UPP",
      MM_MoldCode: "30886",
      MM_TypeShortName: "SPH",
      MM_LensName: "7ID3282N",
      MM_MaxStock: 6900,
      MM_MinStock: 1300,
      MM_PlantNumber: "62000200000030807",
      MM_ItemNumber: null,
      MM_Class: null,
      UA_CodeUpdateBy: null,
      MM_UpdateOn: null,
    },
    {
      MM_ID: 24,
      MM_UpLowName: "LOW",
      MM_MoldCode: "510069",
      MM_TypeShortName: "SPH",
      MM_LensName: "UYS94 5",
      MM_MaxStock: 7000,
      MM_MinStock: 1300,
      MM_PlantNumber: "62000200000510007",
      MM_ItemNumber: "H",
      MM_Class: null,
      UA_CodeUpdateBy: null,
      MM_UpdateOn: null,
    },
    {
      MM_ID: 25,
      MM_UpLowName: "LOW",
      MM_MoldCode: "510241",
      MM_TypeShortName: "SPH",
      MM_LensName: "525K 12",
      MM_MaxStock: 7100,
      MM_MinStock: 1400,
      MM_PlantNumber: "62000200000510207",
      MM_ItemNumber: null,
      MM_Class: null,
      UA_CodeUpdateBy: null,
      MM_UpdateOn: null,
    },
    {
      MM_ID: 26,
      MM_UpLowName: "UPP",
      MM_MoldCode: "30887",
      MM_TypeShortName: "SPH",
      MM_LensName: "7ID3283N",
      MM_MaxStock: 7200,
      MM_MinStock: 1500,
      MM_PlantNumber: "62000200000030808",
      MM_ItemNumber: null,
      MM_Class: null,
      UA_CodeUpdateBy: null,
      MM_UpdateOn: null,
    },
    {
      MM_ID: 27,
      MM_UpLowName: "LOW",
      MM_MoldCode: "510070",
      MM_TypeShortName: "SPH",
      MM_LensName: "UYS95 5",
      MM_MaxStock: 7300,
      MM_MinStock: 1500,
      MM_PlantNumber: "62000200000510008",
      MM_ItemNumber: "I",
      MM_Class: null,
      UA_CodeUpdateBy: null,
      MM_UpdateOn: null,
    },
    {
      MM_ID: 28,
      MM_UpLowName: "LOW",
      MM_MoldCode: "510242",
      MM_TypeShortName: "SPH",
      MM_LensName: "525K 13",
      MM_MaxStock: 7400,
      MM_MinStock: 1600,
      MM_PlantNumber: "62000200000510208",
      MM_ItemNumber: null,
      MM_Class: null,
      UA_CodeUpdateBy: null,
      MM_UpdateOn: null,
    },
    {
      MM_ID: 29,
      MM_UpLowName: "UPP",
      MM_MoldCode: "30888",
      MM_TypeShortName: "SPH",
      MM_LensName: "7ID3284N",
      MM_MaxStock: 7500,
      MM_MinStock: 1700,
      MM_PlantNumber: "62000200000030809",
      MM_ItemNumber: null,
      MM_Class: null,
      UA_CodeUpdateBy: null,
      MM_UpdateOn: null,
    },
    {
      MM_ID: 30,
      MM_UpLowName: "LOW",
      MM_MoldCode: "510071",
      MM_TypeShortName: "SPH",
      MM_LensName: "UYS96 5",
      MM_MaxStock: 7600,
      MM_MinStock: 1700,
      MM_PlantNumber: "62000200000510009",
      MM_ItemNumber: "J",
      MM_Class: null,
      UA_CodeUpdateBy: null,
      MM_UpdateOn: null,
    },
  ];

  useEffect(() => {
    setMoldMasterData(data);
  }, []);

  // Filter data based on search text
  const filteredDataSource = moldMasterData.filter((item) =>
    Object.values(item).some((value) =>
      value.toString().toLowerCase().includes(searchText.toLowerCase())
    )
  );

  return (
    <>
      <div className="table-container">
        <div className="table-header2">
          <Input
            placeholder="Search"
            style={{ width: "300px" }}
            value={searchText}
            onChange={handleSearch}
          />
          <div style={{ display: "flex", gap: "10px" }}>
            {/* <Button
              type="primary"
              icon={<Plus size={16} />}
              onClick={showModal}
            >
              New Mold
            </Button> */}
            <Button
              style={{
                backgroundColor: "#28a745",
                color: "#fff",
                display: "flex",
                alignItems: "center",
                gap: "6px",
                border: "none",
              }}
              icon={<Upload size={16} />}
              onClick={showImportModal}
            >
              Import
            </Button>
          </div>
          <ModalAddMoldMaster
            isModalOpen={isModalOpen}
            setIsModalOpen={setIsModalOpen}
          />
          <ModalImportMoldMaster
            isModalOpen={isImportModalOpen}
            setIsModalOpen={setIsImportModalOpen}
          />
        </div>
        <div className="table-content">
          <Spin spinning={loading}>
            <Tables
              columns={columns}
              dataSource={filteredDataSource.map((item) => ({
                ...item,
                key: item.MM_ID,
              }))}
              scrollY={0.6}
              scrollX={"max-content"}
              bordered={true}
            />
          </Spin>
        </div>
      </div>

      <section>
        <NotificationAPI
          openNotification={openNotification}
          description={description}
        />
        <DrawerDetailMoldMaster
          open={openDrawerDetail}
          onClose={onCloseDrawerDetail}
          record={selectedRecord}
        />
      </section>
    </>
  );
};

export default MoldMaster;
