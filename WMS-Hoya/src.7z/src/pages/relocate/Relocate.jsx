import React from "react";

const Relocat = () => {
  return <div>Relocate</div>;
};

export default Relocat;
