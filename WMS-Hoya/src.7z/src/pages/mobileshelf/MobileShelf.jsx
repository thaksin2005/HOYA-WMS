import React from "react";

const MobileShelf = () => {
  return <div>Mobile Shelf </div>;
};

export default MobileShelf ;
