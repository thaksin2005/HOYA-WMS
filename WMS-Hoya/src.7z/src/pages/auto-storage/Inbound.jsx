import React, { useState, useEffect } from "react";
import { Row, Col, Button, Form, Input, Spin, Checkbox } from "antd";
import { PlusOutlined } from "@ant-design/icons";
import moment from "moment";
import "../../styles/autostorage.css";
import Tables from "../../components/Tables";
import DropdownActionTable from "../../components/dropdown/DropdownActionTable";
import DrawerAdd from "./components/DrawerAddInbound";
import DrawerDetail from "./components/DrawerDetail";
import axios from "axios";
import NotificationAPI from "../../components/NotificationAPI";
import calculateColumnWidth from "../../function/CalcWidth";
import ActionHeaderTableIR from "./components/ActionHeaderTableIR";
import ModalImportExcel from "../../components/modal/ModalImportExcel";
import ActionFooterTable from "../../components/ActionFooterTable";
import { Link } from "react-router-dom";

const Inbound = () => {
  const [openDrawer, setOpenDrawer] = useState(false);
  const [openDrawerDetail, setOpenDrawerDetail] = useState(false);
  const [openNotification, setOpenNotification] = useState(null);
  const [description, setDescription] = useState(null);
  const [loading, setLoading] = useState(true);
  const [dataInbound, setDataInbound] = useState([]);
  const [selectedRecord, setSelectedRecord] = useState(null);
  const [totalItem, setTotalItem] = useState(0);
  const [totalQty, setTotalQty] = useState(0);
  const [onProcessCount, setOnProcessCount] = useState(0);
  const [completedCount, setCompletedCount] = useState(0);
  const [searchText, setSearchText] = useState("");
  const [isModalImportExcelOpen, setIsModalImportExcelOpen] = useState(false);
  const [handleResetClick, setHandleResetClick] = useState(false);
  const [selectedRows, setSelectedRows] = useState([]); // State สำหรับเก็บ row ที่ถูกเลือก

  const showDrawer = () => setOpenDrawer(true);
  const onCloseDrawer = () => setOpenDrawer(false);
  const onCloseDrawerDetail = () => setOpenDrawerDetail(false);
  const [form] = Form.useForm();

  const handleSubmit = () => {
    // ...
  };

  const handleDetailClick = (record) => {
    // ...
  };

  const filters = (dataSource, searchText) => {
    // ...
  };

  const columns = [
    {
      title: "Select",
      dataIndex: "checkbox",
      key: "checkbox",
      width: "3%",
      align: "center",
      fixed: "left",
      render: (text, record) => (
        <Checkbox
          checked={selectedRows.includes(record.key)} 
          onChange={(e) => {
            const checked = e.target.checked;
            setSelectedRows(checked
              ? [...selectedRows, record.key] 
              : selectedRows.filter((key) => key !== record.key) 
            );
          }}
        />
      ),
    },
    {
      title: "No.",
      dataIndex: "no",
      key: "no",
      width: "3%",
      align: "center",
      fixed: "left",
    },
    {
      title: "Inbound No",
      dataIndex: "InboundNo",
      key: "InboundNo",
      width: calculateColumnWidth("Inbound No"),
      sorter: (a, b) => a.InboundNo.localeCompare(b.InboundNo),
      fixed: "left",
      align: "center",
      sticky: true,
      render: (text, record) => (
        <Link 
          to={`/auto-storage/inbound-master?irId=${record.id}&filter=IR_ID`}
          state={{ 
            inboundNo: text,
            relIdType: 'IR_ID',
            irId: record.id
          }}
        >
          {text}
        </Link>
      ),
    },
    {
      title: "Job Number",
      dataIndex: "JobNumber",
      key: "JobNumber",
      width: calculateColumnWidth("Job Number"),
      sorter: (a, b) => a.JobNumber - b.JobNumber,
      fixed: "left",
      align: "center",
    },
    {
      title: "Status",
      dataIndex: "Status",
      key: "Status",
      width: calculateColumnWidth("Status"),
      sorter: (a, b) => a.Status.localeCompare(b.Status),
      align: "center",
    },
    {
      title: "Factory Name",
      dataIndex: "FactoryName",
      key: "FactoryName",
      width: calculateColumnWidth("Factory Name"),
      sorter: (a, b) => a.FactoryName.localeCompare(b.FactoryName),
      align: "center",
    },
    {
      title: "Warehouse Name",
      dataIndex: "WarehouseName",
      key: "WarehouseName",
      width: calculateColumnWidth("Warehouse Name"),
      sorter: (a, b) => a.WarehouseName.localeCompare(b.WarehouseName),
      align: "center",
    },
    {
      title: "Plant Name",
      dataIndex: "PlantName",
      key: "PlantName",
      width: calculateColumnWidth("Plant Name"),
      sorter: (a, b) => a.PlantName.localeCompare(b.PlantName),
      align: "center",
    },
    {
      title: "Interface File",
      dataIndex: "InterfaceFile",
      key: "InterfaceFile",
      width: calculateColumnWidth("Interface File"),
      align: "center",
    },
    {
      title: "User Code",
      dataIndex: "UserCode",
      key: "UserCode",
      width: calculateColumnWidth("User Code"),
      sorter: (a, b) => a.UserCode.localeCompare(b.UserCode),
      align: "center",
    },
    {
      title: "User Full Name",
      dataIndex: "UserFullName",
      key: "UserFullName",
      width: calculateColumnWidth("User Full Name"),
      sorter: (a, b) => a.UserFullName.localeCompare(b.UserFullName),
      align: "center",
    },
    {
      title: "Record On",
      dataIndex: "RecordOn",
      key: "RecordOn",
      width: calculateColumnWidth("Record On"),
      sorter: (a, b) => a.RecordOn.localeCompare(b.RecordOn),
      align: "center",
    },
    {
      title: "More",
      dataIndex: "more",
      key: "more",
      render: (text, record) => (
        <DropdownActionTable onDetailClick={handleDetailClick} record={record} />
      ),
      width: "60px",
      align: "center",
      fixed: "right",
    },
  ];

  const getInbound = async () => {
    try {
      const response = await axios.get(
        "http://localhost:1234/api/InboundDetail-requests"
      );

      const data = response.data.map((item, index) => ({
        id: item.IR_IDInboundRequest,
        key: item.IR_IDInboundRequest, // key สำคัญมาก ห้ามซ้ำกัน
        no: (index + 1).toString(),
        InboundNo: item.IR_Number,
        JobNumber: item.IR_JobNumber,
        Status: item.IR_Status,
        FactoryName: item.F_Name,
        WarehouseName: item.W_Name,
        PlantName: item.P_Name,
        InterfaceFile: item.IR_InterfaceFile,
        UserCode: item.UA_Code,
        UserFullName: item.UA_Fullname,
        RecordOn: item.IR_RecordOn,
        more: <DropdownActionTable onDetailClick={handleDetailClick} record={item} />,
        checkbox: false, // เพิ่ม field checkbox และกำหนดค่าเริ่มต้นเป็น false
      }));

      setTotalItem(data.length);
      setTotalQty(data.reduce((acc, item) => acc + item.qty, 0));

      const onProcess = data.filter((item) => item.status === "On Process").length;
      const completed = data.filter((item) => item.status === "Completed").length;

      setOnProcessCount(onProcess);
      setCompletedCount(completed);

      setDataInbound(data);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    getInbound();
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      if (dataInbound.length > 0) {
        const checkNewData = async () => {
          const response = await axios.get("api/TaskInboundDetail-requests");
          const newData = response.data.filter(
            (item) => !dataInbound.some((data) => data.key === item.TI_ID)
          );

          if (newData.length > 0) {
            getInbound();
            setOpenNotification("info");
            setDescription("New data is added " + newData.length + " record");
          }
        };
        checkNewData();
      }
    }, 2000);

    return () => clearInterval(interval);
  }, [dataInbound]);

  useEffect(() => {
    setLoading(dataInbound.length === 0);
  }, [dataInbound]);

  const filteredData = dataInbound.filter((item) =>
    Object.values(item).some((value) =>
      value ? value.toString().toLowerCase().includes(searchText.toLowerCase()) : false
    )
  );

  return (
    <>
      <div className="table-container">
        <div className="table-header">
          <ActionHeaderTableIR
            AddButton={showDrawer}
            setIsModalImportExcelOpen={setIsModalImportExcelOpen}
            handleResetClick={handleResetClick}
            setHandleResetClick={() => setHandleResetClick(false)}
          />
          {/* เพิ่มแสดง Total Item, On Process, Completed บนหัวตาราง */}
          <Row gutter={16} style={{ marginTop: "2px", display: "flex", justifyContent: "flex-end", alignItems: "center" }}>
            <Col span={3} xs={6} sm={8} md={8} lg={3} xl={3}>
              <div className="detail-input">
                <span>Item:</span>
                <strong>{totalItem}</strong>
              </div>
            </Col>

            <Col span={3} xs={6} sm={8} md={8} lg={3} xl={3}>
              <div className="detail-input">
                <span>On Process:</span>
                <strong>{onProcessCount}</strong>
              </div>
            </Col>

            <Col span={3} xs={6} sm={8} md={8} lg={3} xl={3}>
              <div className="detail-input">
                <span>Completed:</span>
                <strong>{completedCount}</strong>
              </div>
            </Col>
          </Row>



        </div>
        
        <section style={{ marginTop: "10px" }}>
          <Spin spinning={loading}>
            <Tables
              columns={columns}
              dataSource={filteredData}
              bordered
              scrollY={0.5}
              scrollX={"max-content"}
              maxHeight={"480px"}
            />
          </Spin>
        </section>

        <div className="action-footer-table">
          {/* <ActionFooterTable handleReset={() => setHandleResetClick(true)} /> */}
        </div>
      </div>

      <section>
        <NotificationAPI openNotification={openNotification} description={description} />
        <DrawerAdd open={openDrawer} onClose={onCloseDrawer} />
        <DrawerDetail open={openDrawerDetail} onClose={onCloseDrawerDetail} record={selectedRecord} />
      </section>

      <ModalImportExcel isModalOpen={isModalImportExcelOpen} setIsModalOpen={setIsModalImportExcelOpen} />
    </>
  );
};

export default Inbound;
