// import React, { useState, useEffect } from "react";
// import { Row, Col, Button, Form, Input, Spin, Checkbox } from "antd";
// import { PlusOutlined } from "@ant-design/icons";
// import moment from "moment";
// import "../../styles/autostorage.css";
// import Tables from "../../components/Tables";
// import DropdownActionTable from "../../components/dropdown/DropdownActionTable";
// import DrawerAdd from "./components/DrawerAddInbound";
// import DrawerDetail from "./components/DrawerDetail";
// import axios from "axios";
// import NotificationAPI from "../../components/NotificationAPI";
// import calculateColumnWidth from "../../function/CalcWidth";
// import ActionHeaderTableIR from "./components/ActionHeaderTableIR";
// import ModalImportExcel from "../../components/modal/ModalImportExcel";
// import ActionFooterTable from "../../components/ActionFooterTable";
// import { Link } from "react-router-dom";

// const Outbound = () => {
//   const [openDrawer, setOpenDrawer] = useState(false);
//   const [openDrawerDetail, setOpenDrawerDetail] = useState(false);
//   const [openNotification, setOpenNotification] = useState(null);
//   const [description, setDescription] = useState(null);
//   const [loading, setLoading] = useState(true);
//   const [dataInbound, setDataInbound] = useState([]);
//   const [selectedRecord, setSelectedRecord] = useState(null);
//   const [totalItem, setTotalItem] = useState(0);
//   const [totalQty, setTotalQty] = useState(0);
//   const [onProcessCount, setOnProcessCount] = useState(0);
//   const [completedCount, setCompletedCount] = useState(0);
//   const [searchText, setSearchText] = useState("");
//   const [isModalImportExcelOpen, setIsModalImportExcelOpen] = useState(false);
//   const [handleResetClick, setHandleResetClick] = useState(false);
//   const [selectedRows, setSelectedRows] = useState([]); // State สำหรับเก็บ row ที่ถูกเลือก

//   const showDrawer = () => setOpenDrawer(true);
//   const onCloseDrawer = () => setOpenDrawer(false);
//   const onCloseDrawerDetail = () => setOpenDrawerDetail(false);
//   const [form] = Form.useForm();

//   const handleSubmit = () => {
//     // ...
//   };

//   const handleDetailClick = (record) => {
//     // ...
//   };

//   const filters = (dataSource, searchText) => {
//     // ...
//   };

//   const columns = [
//     {
//       title: "Select",
//       dataIndex: "checkbox",
//       key: "checkbox",
//       width: "3%",
//       align: "center",
//       fixed: "left",
//       render: (text, record) => (
//         <Checkbox
//           checked={selectedRows.includes(record.key)}
//           onChange={(e) => {
//             const checked = e.target.checked;
//             setSelectedRows(
//               checked
//                 ? [...selectedRows, record.key]
//                 : selectedRows.filter((key) => key !== record.key)
//             );
//           }}
//         />
//       ),
//     },
//     {
//       title: "No.",
//       dataIndex: "no",
//       key: "no",
//       width: "3%",
//       align: "center",
//       fixed: "left",
//     },
//     {
//       title: "Outbound No",
//       dataIndex: "OR_Number",
//       key: "OR_Number",
//       width: calculateColumnWidth("Outbound No"),
//       sorter: (a, b) => a.OR_Number.localeCompare(b.OR_Number),
//       fixed: "left",
//       align: "center",
//       sticky: true,
//       render: (text, record) => (
//         <Link
//           to={`/auto-storage/outbound-master?orId=${record.OR_IDOutboundRequest}&filter=OR_ID`} // Update link and params
//           state={{
//             outboundNo: text,
//             relIdType: 'OR_ID', // Update relIdType
//             orId: record.OR_IDOutboundRequest, // Update id field
//           }}
//         >
//           {text}
//         </Link>
//       ),
//     },
//     {
//       title: "Job Number",
//       dataIndex: "OR_JobNumber",
//       key: "OR_JobNumber",
//       width: calculateColumnWidth("Job Number"),
//       sorter: (a, b) => a.OR_JobNumber - b.OR_JobNumber,
//       fixed: "left",
//       align: "center",
//     },
//     {
//       title: "Status",
//       dataIndex: "OR_Status",
//       key: "OR_Status",
//       width: calculateColumnWidth("Status"),
//       sorter: (a, b) => a.OR_Status.localeCompare(b.OR_Status),
//       align: "center",
//     },
//     {
//       title: "Factory Name",
//       dataIndex: "F_Name",
//       key: "F_Name",
//       width: calculateColumnWidth("Factory Name"),
//       sorter: (a, b) => a.F_Name.localeCompare(b.F_Name),
//       align: "center",
//     },
//     {
//       title: "Warehouse Name",
//       dataIndex: "W_Name",
//       key: "W_Name",
//       width: calculateColumnWidth("Warehouse Name"),
//       sorter: (a, b) => a.W_Name.localeCompare(b.W_Name),
//       align: "center",
//     },
//     {
//       title: "Plant Name",
//       dataIndex: "P_Name",
//       key: "P_Name",
//       width: calculateColumnWidth("Plant Name"),
//       sorter: (a, b) => a.P_Name.localeCompare(b.P_Name),
//       align: "center",
//     },
//     {
//       title: "Interface File",
//       dataIndex: "OR_InterfaceFile",
//       key: "OR_InterfaceFile",
//       width: calculateColumnWidth("Interface File"),
//       align: "center",
//     },
//     {
//       title: "User Code",
//       dataIndex: "UA_Code",
//       key: "UA_Code",
//       width: calculateColumnWidth("User Code"),
//       sorter: (a, b) => a.UA_Code.localeCompare(b.UA_Code),
//       align: "center",
//     },
//     {
//       title: "User Full Name",
//       dataIndex: "UA_Fullname",
//       key: "UA_Fullname",
//       width: calculateColumnWidth("User Full Name"),
//       sorter: (a, b) => a.UA_Fullname.localeCompare(b.UA_Fullname),
//       align: "center",
//     },
//     {
//       title: "Record On",
//       dataIndex: "OR_RecordOn",
//       key: "OR_RecordOn",
//       width: calculateColumnWidth("Record On"),
//       sorter: (a, b) => a.OR_RecordOn.localeCompare(b.OR_RecordOn),
//       align: "center",
//     },
//     {
//       title: "More",
//       dataIndex: "more",
//       key: "more",
//       render: (text, record) => (
//         <DropdownActionTable onDetailClick={handleDetailClick} record={record} />
//       ),
//       width: "60px",
//       align: "center",
//       fixed: "right",
//     },
//   ];

//   const getInbound = async () => {
//     try {
//       const response = await axios.get(
//         "http://localhost:1234/api/OutboundDetail-requests"
//       );

//       const data = response.data.map((item, index) => ({
//         OR_IDOutboundRequest: item.OR_IDOutboundRequest, // Use correct ID field
//         key: item.OR_IDOutboundRequest, // Key must match and be unique
//         no: (index + 1).toString(),
//         OR_Number: item.OR_Number,
//         OR_JobNumber: item.OR_JobNumber,
//         OR_Status: item.OR_Status,
//         F_Name: item.F_Name,
//         W_Name: item.W_Name,
//         P_Name: item.P_Name,
//         OR_InterfaceFile: item.OR_InterfaceFile,
//         UA_Code: item.UA_Code,
//         UA_Fullname: item.UA_Fullname,
//         OR_RecordOn: item.OR_RecordOn,
//         more: <DropdownActionTable onDetailClick={handleDetailClick} record={item} />,
//         checkbox: false,
//       }));

//       setTotalItem(data.length);
//       setTotalQty(data.reduce((acc, item) => acc + item.qty, 0));

//       const onProcess = data.filter((item) => item.status === "On Process").length;
//       const completed = data.filter((item) => item.status === "Completed").length;

//       setOnProcessCount(onProcess);
//       setCompletedCount(completed);

//       setDataInbound(data);
//     } catch (error) {
//       console.error("Error fetching data:", error);
//     }
//   };

//   useEffect(() => {
//     getInbound();
//   }, []);

//   useEffect(() => {
//     const interval = setInterval(() => {
//       if (dataInbound.length > 0) {
//         const checkNewData = async () => {
//           const response = await axios.get("api/OutboundDetail-requests");
//           const newData = response.data.filter(
//             (item) => !dataInbound.some((data) => data.key === item.TI_ID)
//           );

//           if (newData.length > 0) {
//             getInbound();
//             setOpenNotification("info");
//             setDescription("New data is added " + newData.length + " record");
//           }
//         };
//         checkNewData();
//       }
//     }, 2000);

//     return () => clearInterval(interval);
//   }, [dataInbound]);

//   useEffect(() => {
//     setLoading(dataInbound.length === 0);
//   }, [dataInbound]);

//   const filteredData = dataInbound.filter((item) =>
//     Object.values(item).some((value) =>
//       value ? value.toString().toLowerCase().includes(searchText.toLowerCase()) : false
//     )
//   );

//   return (
//     <>
//       <div className="table-container">
//         <div className="table-header">
//           <ActionHeaderTableIR
//             AddButton={showDrawer}
//             setIsModalImportExcelOpen={setIsModalImportExcelOpen}
//             handleResetClick={handleResetClick}
//             setHandleResetClick={() => setHandleResetClick(false)}
//           />
//           {/* เพิ่มแสดง Total Item, On Process, Completed บนหัวตาราง */}
//           <Row gutter={16} style={{ marginTop: "2px", display: "flex", justifyContent: "flex-end", alignItems: "center" }}>
//             <Col span={3} xs={6} sm={8} md={8} lg={3} xl={3}>
//               <div className="detail-input">
//                 <span>Item:</span>
//                 <strong>{totalItem}</strong>
//               </div>
//             </Col>

//             <Col span={3} xs={6} sm={8} md={8} lg={3} xl={3}>
//               <div className="detail-input">
//                 <span>On Process:</span>
//                 <strong>{onProcessCount}</strong>
//               </div>
//             </Col>

//             <Col span={3} xs={6} sm={8} md={8} lg={3} xl={3}>
//               <div className="detail-input">
//                 <span>Completed:</span>
//                 <strong>{completedCount}</strong>
//               </div>
//             </Col>
//           </Row>



//         </div>
        
//         <section style={{ marginTop: "10px" }}>
//           <Spin spinning={loading}>
//             <Tables
//               columns={columns}
//               dataSource={filteredData}
//               bordered
//               scrollY={0.5}
//               scrollX={"max-content"}
//               maxHeight={"480px"}
//             />
//           </Spin>
//         </section>

//         <div className="action-footer-table">
//           {/* <ActionFooterTable handleReset={() => setHandleResetClick(true)} /> */}
//         </div>
//       </div>

//       <section>
//         <NotificationAPI openNotification={openNotification} description={description} />
//         <DrawerAdd open={openDrawer} onClose={onCloseDrawer} />
//         <DrawerDetail open={openDrawerDetail} onClose={onCloseDrawerDetail} record={selectedRecord} />
//       </section>

//       <ModalImportExcel isModalOpen={isModalImportExcelOpen} setIsModalOpen={setIsModalImportExcelOpen} />
//     </>
//   );
// };

// export default Outbound;

import React, { useState, useEffect } from "react";
import { Row, Col, Button, Form, Input, Spin, Checkbox } from "antd";
import moment from "moment";
import "../../styles/autostorage.css";
import Tables from "../../components/Tables";
import DropdownActionTable from "../../components/dropdown/DropdownActionTable";
import DrawerAdd from "./components/DrawerAddOutbound";
import DrawerDetail from "./components/DrawerDetail";
import axios from "axios";
import NotificationAPI from "../../components/NotificationAPI";
import calculateColumnWidth from "../../function/CalcWidth";
import ActionHeaderTable from "./components/ActionHeaderTable";
import ActionFooterTable from "../../components/ActionFooterTable";

const OutboundMaster = () => {
  const [openDrawer, setOpenDrawer] = useState(false);
  const [openDrawerDetail, setOpenDrawerDetail] = useState(false);
  const [openNotification, setOpenNotification] = useState(null);
  const [description, setDescription] = useState(null);
  const [loading, setLoading] = useState(true);
  const [dataOutbound, setDataOutbound] = useState([]);
  const [selectedRecord, setSelectedRecord] = useState(null);
  const [totalItem, setTotalItem] = useState(0);
  const [totalQty, setTotalQty] = useState(0);
  const [totalOnProcess, setTotalOnProcess] = useState(0);
  const [totalCompleted, setTotalCompleted] = useState(0);
  const [searchText, setSearchText] = useState("");
  const [handleResetClick, setHandleResetClick] = useState(false);
  const [selectedRowKeys, setSelectedRowKeys] = useState([]); // State สำหรับเก็บ key ของรายการที่ถูกเลือก

  // ฟังก์ชันเปิด/ปิด Drawer
  const showDrawer = () => {
    setOpenDrawer(true);
  };

  const onCloseDrawer = () => {
    setOpenDrawer(false);
  };

  const onCloseDrawerDetail = () => {
    setOpenDrawerDetail(false);
  };

  // ตัวเลือกสำหรับ Select
  const warehouseOptions = [
    { value: "1", label: "#1 - Warehouse 1" },
    { value: "2", label: "#2 - Warehouse 2" },
    { value: "3", label: "#3 - Warehouse 3" },
  ];

  const pointOptions = [
    { value: "1", label: "#1 - Point 1" },
    { value: "2", label: "#2 - Point 2" },
    { value: "3", label: "#3 - Point 3" },
  ];

  const [form] = Form.useForm();

  // ฟังก์ชันจัดการการส่งฟอร์ม
  const handleSubmit = () => {
    const formValues = form.getFieldsValue();
    const formattedDate = formValues.DateCreated
      ? moment(formValues.DateCreated).format("YYYY-MM-DD")
      : null;
    console.log("Form submitted");
    console.log({ ...formValues, DateCreated: formattedDate });
  };

  // ฟังก์ชันเมื่อคลิกดูราละเอียด
  const handleDetailClick = (record) => {
    setSelectedRecord(record);
    setOpenDrawerDetail(true);
  };

  // ฟังก์ชันสำหรับการเลือกหรือยกเลิกการเลือกทั้งหมด
  const onSelectAll = (e) => {
    if (e.target.checked) {
      const allKeys = dataOutbound.map((item) => item.no);
      setSelectedRowKeys(allKeys);
    } else {
      setSelectedRowKeys([]);
    }
  };

  // ฟังก์ชันสำหรับการเลือกหรือยกเลิกการเลือกรายการเดียว
  const onSelect = (record, selected) => {
    if (selected) {
      setSelectedRowKeys([...selectedRowKeys, record.no]);
    } else {
      setSelectedRowKeys(selectedRowKeys.filter((key) => key !== record.no));
    }
  };

  // กำหนดคอลัมน์ของตาราง
  const columns = [
    {
      title: (
        <Checkbox
        
          indeterminate={
            selectedRowKeys.length > 0 &&
            selectedRowKeys.length < dataOutbound.length
          }
          checked={
            selectedRowKeys.length === dataOutbound.length &&
            dataOutbound.length > 0
          }
          onChange={onSelectAll}
          
        />
      ),
      dataIndex: "checkbox",
      key: "checkbox",
      align: "center",
      fixed: "left",
      width: 50,
      render: (text, record) => (
        <Checkbox
          checked={selectedRowKeys.includes(record.no)}
          onChange={(e) => onSelect(record, e.target.checked)}
        />
      ),
    },
    { title: 'No', 
      dataIndex: 'no', 
      key: 'no', 
      align: "center", 
      fixed: "left", 
      minWidth: 80, 
      sorter: (a, b) => a.no - b.no },        
    { 
      title: 'Tray Number Upper',
      dataIndex: 'TrayNumberUPP', 
      key: 'TrayNumberUPP', align: "center", 
      fixed: "left", minWidth: 100, 
      sorter: (a, b) => a.ORI_IDOutboundRequestItem.localeCompare(b.ORI_IDOutboundRequestItem) 
    },
    { 
      title: 'Location Upper',
      dataIndex: 'LocationUPP', 
      key: 'LocationUPP', align: "center", 
      fixed: "left", minWidth: 100, sorter: (a, b) => a.ORI_IDOutboundRequestItem.localeCompare(b.ORI_IDOutboundRequestItem) 
    },
    { 
      title: 'MoldSerial Upper',
      dataIndex: 'MoldSerialUPP', 
      key: 'MoldSerialUPP', align: "center", 
      fixed: "left", minWidth: 100, sorter: (a, b) => a.ORI_IDOutboundRequestItem.localeCompare(b.ORI_IDOutboundRequestItem) 
    },
    { 
      title: 'MoldSerial Lower',
      dataIndex: 'MoldSerialLOW', 
      key: 'MoldSerialLOW', align: "center", 
      fixed: "left", minWidth: 100, sorter: (a, b) => a.ORI_IDOutboundRequestItem.localeCompare(b.ORI_IDOutboundRequestItem) 
    },
    { 
      title: 'TrayNumber Lower',
      dataIndex: 'TrayNumberLOW', 
      key: 'TrayNumberLOW', align: "center", 
      fixed: "left", minWidth: 100, sorter: (a, b) => a.ORI_IDOutboundRequestItem.localeCompare(b.ORI_IDOutboundRequestItem) 
    },
    { 
      title: 'Location Lower',
      dataIndex: 'LocationLOW', 
      key: 'LocationLOW', align: "center", 
      fixed: "left", minWidth: 100, sorter: (a, b) => a.ORI_IDOutboundRequestItem.localeCompare(b.ORI_IDOutboundRequestItem) 
    },

    // { title: 'Outbound Status', dataIndex: 'OutboundItemStatus', key: 'OutboundItemStatus', align: "center", fixed: "left", minWidth: 150, sorter: (a, b) => a.OutboundItemStatus.localeCompare(b.OutboundItemStatus) },
    // { title: 'Production Order', dataIndex: 'ProductionOrder', key: 'ProductionOrder', align: "center", fixed: "left", minWidth: 150, sorter: (a, b) => a.ProductionOrder.localeCompare(b.ProductionOrder) },
    // { title: 'Order Date', dataIndex: 'OrderDate', key: 'OrderDate', align: "center", minWidth: 120, sorter: (a, b) => new Date(a.OrderDate) - new Date(b.OrderDate) },
    // { title: 'Input Date', dataIndex: 'InputDate', key: 'InputDate', align: "center", minWidth: 130, sorter: (a, b) => new Date(a.InputDate) - new Date(b.InputDate) },
    // { title: 'Request Date', dataIndex: 'RequestDate', key: 'RequestDate', align: "center", minWidth: 120, sorter: (a, b) => new Date(a.RequestDate) - new Date(b.RequestDate) },
    // { title: 'Send ID', dataIndex: 'SendID', key: 'SendID', align: "center", minWidth: 100, sorter: (a, b) => a.SendID - b.SendID },
    // { title: 'Input ID', dataIndex: 'InputID', key: 'InputID', align: "center", minWidth: 100, sorter: (a, b) => a.InputID - b.InputID },
    // { title: 'Test', dataIndex: 'Test', key: 'Test', align: "center", minWidth: 80 },
    // { title: 'Edge', dataIndex: 'Edge', key: 'Edge', align: "center", minWidth: 80 },
    // { title: 'Lot Msg', dataIndex: 'LotMsg', key: 'LotMsg', align: "center", minWidth: 100, sorter: (a, b) => a.LotMsg.localeCompare(b.LotMsg) },
    // { title: 'Lot Type', dataIndex: 'LotType', key: 'LotType', align: "center", minWidth: 100, sorter: (a, b) => a.LotType.localeCompare(b.LotType) },
    // { title: 'Route ID', dataIndex: 'RouteID', key: 'RouteID', align: "center", minWidth: 80, sorter: (a, b) => a.RouteID - b.RouteID },
    // { title: 'Lens FlagDesc', dataIndex: 'LensFlagDesc', key: 'LensFlagDesc', align: "center", minWidth: 140, sorter: (a, b) => a.LensFlagDesc.localeCompare(b.LensFlagDesc) },
    // { title: 'Product DIA', dataIndex: 'ProductDIA', key: 'ProductDIA', align: "center", minWidth: 120, sorter: (a, b) => a.ProductDIA - b.ProductDIA },
    // { title: 'End Item Name', dataIndex: 'EndItemName', key: 'EndItemName', align: "center", minWidth: 140, sorter: (a, b) => a.EndItemName.localeCompare(b.EndItemName) },
    // { title: 'Cast Oven No', dataIndex: 'CastOvenNo', key: 'CastOvenNo', align: "center", minWidth: 140, sorter: (a, b) => a.CastOvenNo - b.CastOvenNo },
    // { title: 'Oven Input Time', dataIndex: 'OvenInputTime', key: 'OvenInputTime', align: "center", minWidth: 140, sorter: (a, b) => new Date(a.OvenInputTime) - new Date(b.OvenInputTime) },
    // { title: 'Oven Time', dataIndex: 'OvenMMTime', key: 'OvenMMTime', align: "center", minWidth: 110, sorter: (a, b) => new Date(a.OvenMMTime) - new Date(b.OvenMMTime) },
    // { title: 'Mold Upper', dataIndex: 'MoldUpper', key: 'MoldUpper', align: "center", minWidth: 120, sorter: (a, b) => a.MoldUpper - b.MoldUpper },
    // { title: 'Mold Upper Name', dataIndex: 'MoldUpperName', key: 'MoldUpperName', align: "center", minWidth: 160, sorter: (a, b) => a.MoldUpperName.localeCompare(b.MoldUpperName) },
    // { title: 'Mold Upper DIA', dataIndex: 'MoldUpperDIA', key: 'MoldUpperDIA', align: "center", minWidth: 140, sorter: (a, b) => a.MoldUpperDIA - b.MoldUpperDIA },
    // { title: 'Mold Serial Upper', dataIndex: 'MoldSerialUPP', key: 'MoldSerialUPP', align: "center", minWidth: 100 },
    // { title: 'Tray Number Upper', dataIndex: 'TrayNumberUPP', key: 'TrayNumberUPP', align: "center", minWidth: 160, sorter: (a, b) => a.TrayNumberUPP - b.TrayNumberUPP },
    // { title: 'Position Upper', dataIndex: 'PositionUPP', key: 'PositionUPP', align: "center", minWidth: 140, sorter: (a, b) => a.PositionUPP - b.PositionUPP },
    // { title: 'Location Upper', dataIndex: 'LocationUPP', key: 'LocationUPP', align: "center", minWidth: 120 },
    // { title: 'Mold Lower', dataIndex: 'MoldLower', key: 'MoldLower', align: "center", minWidth: 120, sorter: (a, b) => a.MoldLower - b.MoldLower },
    // { title: 'Mold Lower Name', dataIndex: 'MoldLowerName', key: 'MoldLowerName', align: "center", minWidth: 160, sorter: (a, b) => a.MoldLowerName.localeCompare(b.MoldLowerName) },
    // { title: 'Mold Lower DIA', dataIndex: 'MoldLowerDIA', key: 'MoldLowerDIA', align: "center", minWidth: 150, sorter: (a, b) => a.MoldLowerDIA - b.MoldLowerDIA },
    // { title: 'Mold Serial LOW', dataIndex: 'MoldSerialLOW', key: 'MoldSerialLOW', align: "center", minWidth: 100 },
    // { title: 'Tray Number LOW', dataIndex: 'TrayNumberLOW', key: 'TrayNumberLOW', align: "center", minWidth: 150, sorter: (a, b) => a.TrayNumberLOW - b.TrayNumberLOW },
    // { title: 'Position LOW', dataIndex: 'PositionLOW', key: 'PositionLOW', align: "center", minWidth: 130, sorter: (a, b) => a.PositionLOW - b.PositionLOW },
    // { title: 'Location LOW', dataIndex: 'LocationLOW', key: 'LocationLOW', align: "center", minWidth: 100 },
    // { title: 'Warehouse', dataIndex: 'Warehouse', key: 'Warehouse', align: "center", minWidth: 100, sorter: (a, b) => a.Warehouse.localeCompare(b.Warehouse) },
    // { title: 'Instruction', dataIndex: 'Instruction', key: 'Instruction', align: "center", minWidth: 100 },
    // { title: 'LotNo', dataIndex: 'LotNo', key: 'LotNo', align: "center", minWidth: 100 },
    // { title: 'Current Route Seq', dataIndex: 'CurrentRouteSeq', key: 'CurrentRouteSeq', align: "center", minWidth: 150, sorter: (a, b) => a.CurrentRouteSeq - b.CurrentRouteSeq },
    // { title: 'Current Process Name', dataIndex: 'CurrentProcessName', key: 'CurrentProcessName', align: "center", minWidth: 180, sorter: (a, b) => a.CurrentProcessName.localeCompare(b.CurrentProcessName) },
    // { title: 'Power Seq', dataIndex: 'PowerSeq', key: 'PowerSeq', align: "center", minWidth: 100, sorter: (a, b) => a.PowerSeq - b.PowerSeq },
    // { title: 'Index Flag', dataIndex: 'IndexFlag', key: 'IndexFlag', align: "center", minWidth: 100 },
    // { title: 'Index Name', dataIndex: 'IndexName', key: 'IndexName', align: "center", minWidth: 100 },
    // { title: 'Finish SPH', dataIndex: 'FinishSPH', key: 'FinishSPH', align: "center", minWidth: 100 },
    // { title: 'Finish CYL', dataIndex: 'FinishCYL', key: 'FinishCYL', align: "center", minWidth: 100 },
    // { title: 'Semi BC', dataIndex: 'SemiBC', key: 'SemiBC', align: "center", minWidth: 100 },
    // { title: 'Semi CT', dataIndex: 'SemiCT', key: 'SemiCT', align: "center", minWidth: 100 },
    // { title: 'Addition', dataIndex: 'Addition', key: 'Addition', align: "center", minWidth: 100 },
    // { title: 'RL', dataIndex: 'RL', key: 'RL', align: "center", minWidth: 100 },
    // { title: 'Vertical Text', dataIndex: 'VerticalText', key: 'VerticalText', align: "center", minWidth: 100 },
    // { title: 'Horizontal Text', dataIndex: 'HorizontalText', key: 'HorizontalText', align: "center", minWidth: 120 },
    // { title: 'Input Qty', dataIndex: 'InputQty', key: 'InputQty', align: "center", minWidth: 100 },
    // { title: 'CT', dataIndex: 'CT', key: 'CT', align: "center", minWidth: 100 },
    // { title: 'Tape Length', dataIndex: 'TapeLength', key: 'TapeLength', align: "center", minWidth: 100 },
    // { title: 'Tape Angle', dataIndex: 'TapeAngle', key: 'TapeAngle', align: "center", minWidth: 100 },
    // { title: 'Tape Overlap', dataIndex: 'TapeOverlap', key: 'TapeOverlap', align: "center", minWidth: 120 },
    // { title: 'Tape Width', dataIndex: 'TapeWidth', key: 'TapeWidth', align: "center", minWidth: 100 },
    // { title: 'Target On', dataIndex: 'TargetOn', key: 'TargetOn', align: "center", minWidth: 100 },
    {
      title: "More",
      dataIndex: "more",
      key: "more",
      render: (text, record) => (
        <DropdownActionTable onDetailClick={handleDetailClick} record={record} />
      ),
      align: "center",
      fixed: "right",
      minWidth: 60,
    },
];

  

  // ฟังก์ชันดึงข้อมูล Outbound
  const getOutbound = async () => {
    try {
      const response = await axios.get(
        "http://localhost:1234/api/OutboundItemDetail-requests"
      );

      const data = response.data.map((item, index) => ({
        no: index + 1,
        TrayNumberUPP: item.TrayNumberUPP || "N/A",
        LocationUPP: item.LocationUPP || "N/A",
        MoldSerialUPP: item.MoldSerialUPP || "N/A",
        MoldSerialLOW: item.MoldSerialLOW || "N/A",
        TrayNumberLOW: item.TrayNumberLOW || "N/A",
        LocationLOW: item.LocationLOW || "N/A",
        //ORI_IDOutboundRequestItem: item.ORI_IDOutboundRequestItem || "N/A",
        // OutboundItemStatus: item.OutboundItemStatus || "N/A",
        // ProductionOrder: item.ProductionOrder || "N/A",
        // OrderDate: item.OrderDate ? moment(item.OrderDate).format("YYYY-MM-DD") : "N/A",
        // InputDate: item.InputDate ? moment(item.InputDate).format("YYYY-MM-DD") : "N/A",
        // RequestDate: item.RequestDate ? moment(item.RequestDate).format("YYYY-MM-DD") : "N/A",
        // SendID: item.SendID || "N/A",
        // InputID: item.InputID || "N/A",
        // Test: item.Test || "N/A",
        // Edge: item.Edge || "N/A",
        // LotMsg: item.LotMsg || "N/A",
        // LotType: item.LotType || "N/A",
        // RouteID: item.RouteID || "N/A",
        // LensFlagDesc: item.LensFlagDesc || "N/A",
        // ProductDIA: item.ProductDIA || "N/A",
        // EndItemName: item.EndItemName || "N/A",
        // CastOvenNo: item.CastOvenNo || "N/A",
        // OvenInputTime: item.OvenInputTime || "N/A",
        // OvenMMTime: item.OvenMMTime || "N/A",
        // MoldUpper: item.MoldUpper || "N/A",
        // MoldUpperName: item.MoldUpperName || "N/A",
        // MoldUpperDIA: item.MoldUpperDIA || "N/A",
        // MoldSerialUPP: item.MoldSerialUPP || "N/A",
        // TrayNumberUPP: item.TrayNumberUPP || "N/A",
        // PositionUPP: item.PositionUPP || "N/A",
        // LocationUPP: item.LocationUPP || "N/A",
        // MoldLower: item.MoldLower || "N/A",
        // MoldLowerName: item.MoldLowerName || "N/A",
        // MoldLowerDIA: item.MoldLowerDIA || "N/A",
        // MoldSerialLOW: item.MoldSerialLOW || "N/A",
        // TrayNumberLOW: item.TrayNumberLOW || "N/A",
        // PositionLOW: item.PositionLOW || "N/A",
        // LocationLOW: item.LocationLOW || "N/A",
        // Warehouse: item.Warehouse || "N/A",
        // Instruction: item.Instruction || "N/A",
        // LotNo: item.LotNo || "N/A",
        // CurrentRouteSeq: item.CurrentRouteSeq || "N/A",
        // CurrentProcessName: item.CurrentProcessName || "N/A",
        // PowerSeq: item.PowerSeq || "N/A",
        // IndexFlag: item.IndexFlag || "N/A",
        // IndexName: item.IndexName || "N/A",
        // FinishSPH: item.FinishSPH || "N/A",
        // FinishCYL: item.FinishCYL || "N/A",
        // SemiBC: item.SemiBC || "N/A",
        // SemiCT: item.SemiCT || "N/A",
        // Addition: item.Addition || "N/A",
        // RL: item.RL || "N/A",
        // VerticalText: item.VerticalText || "N/A",
        // HorizontalText: item.HorizontalText || "N/A",
        // InputQty: item.InputQty || "N/A",
        // CT: item.CT || "N/A",
        // TapeLength: item.TapeLength || "N/A",
        // TapeAngle: item.TapeAngle || "N/A",
        // TapeOverlap: item.TapeOverlap || "N/A",
        // TapeWidth: item.TapeWidth || "N/A",
        // TargetOn: item.TargetOn ? moment(item.TargetOn).format("YYYY-MM-DD") : "N/A",
      }));
      
      
      
      setTotalItem(data.length);
      setTotalOnProcess(data.filter((item) => item.OutboundItemStatus === "Process").length);
      setTotalCompleted(data.filter((item) => item.OutboundItemStatus === "Completed").length);
      setDataOutbound(data);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setLoading(false);
    }
  };

  // ใช้ useEffect เพื่อดึงข้อมูลเมื่อ component ถูก mount
  useEffect(() => {
    getOutbound();
  }, []);

  // ตรวจสอบข้อมูลใหม่ทุกๆ 2 วินาที
  useEffect(() => {
    const interval = setInterval(() => {
      console.log(dataOutbound.length);

      if (dataOutbound.length > 0) {
        const checkNewData = async () => {
          const response = await axios.get("api/TaskOutboundItemDetail-requests");

          const newData = response.data.filter(
            (item) => !dataOutbound.some((data) => data.key === item.TI_ID)
          );

          if (newData.length > 0) {
            getOutbound();
            console.log("New data is added " + newData.length + " record");
            setOpenNotification("info");
            setDescription("New data is added " + newData.length + " record");
          }
        };
        checkNewData();
      }
    }, 2000);

    return () => clearInterval(interval); // ล้าง interval เมื่อ component ถูก unmount
  }, [dataOutbound]);

  // ตรวจสอบสถานะการโหลดข้อมูล
  useEffect(() => {
    if (dataOutbound.length === 0) {
      setLoading(true);
      setTimeout(() => setLoading(false), 100);
    }
    if (dataOutbound.length > 0) {
      setLoading(false);
    }
  }, [dataOutbound]);

  const filteredData = dataOutbound.filter((item) =>
    Object.values(item).some((value) =>
      value
        ? value.toString().toLowerCase().includes(searchText.toLowerCase())
        : false
    )
  );

  return (
    <>

      <div className="table-container">
        <div className="table-header">
          <ActionHeaderTable
            AddButton={showDrawer}
            handleResetClick={handleResetClick}
            setHandleResetClick={() => setHandleResetClick(false)}
          />
             {/* เพิ่มแสดง Total Item, On Process, Completed บนหัวตาราง */}
                      <Row gutter={16} style={{ marginTop: "2px", display: "flex", justifyContent: "flex-end", alignItems: "center" }}>
                        <Col span={3} xs={6} sm={8} md={8} lg={3} xl={3}>
                          <div className="detail-input">
                            <span>Item:</span>
                            <strong>{totalItem}</strong>
                          </div>
                        </Col>
            
                        <Col span={3} xs={6} sm={8} md={8} lg={3} xl={3}>
                          <div className="detail-input">
                            <span>On Process:</span>
                            <strong>{totalOnProcess}</strong>
                          </div>
                        </Col>
            
                        <Col span={3} xs={6} sm={8} md={8} lg={3} xl={3}>
                          <div className="detail-input">
                            <span>Completed:</span>
                            <strong>{totalCompleted}</strong>
                          </div>
                        </Col>
                      </Row>
            

        </div>
        <section style={{ marginTop: "10px" }}>
          <Spin spinning={loading}>
            <Tables
              columns={columns}
              dataSource={filteredData}
              bordered
              scrollY={0.5}
              scrollX={"max-content"}
              maxHeight={"480px"}
            />
          </Spin>
        </section>

        <div className="action-footer-table">
          {/* <ActionFooterTable handleReset={() => setHandleResetClick(true)} /> */}
        </div>
        
      </div>

      {/* ส่วนแสดง Notification และ Drawer */}
      <section>
        <NotificationAPI
          openNotification={openNotification}
          description={description}
        />
        <DrawerAdd open={openDrawer} onClose={onCloseDrawer} />
        <DrawerDetail
          open={openDrawerDetail}
          onClose={onCloseDrawerDetail}
          record={selectedRecord}
        />
      </section>
    </>
  );
};

export default OutboundMaster;

