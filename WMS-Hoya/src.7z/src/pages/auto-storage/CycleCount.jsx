import React from "react";

const CycleCount = () => {
  return <div>Cycle Count </div>;
};

export default CycleCount ;
