import Monitoring from "./Monitoring";
import Inbound from "./Inbound";
import Outbound from "./Outbound";
import CycleCount from "./CycleCount";
import AdjustStock from "./AdjustStock";
import Refill from "./Refill";
import InspectionMold from "./InspectionMold";
import InboundMaster from "./InboundMaster";
import OutboundMaster from "./OutboundMaster";
import { Route, Routes } from "react-router-dom";

const AutoStorageRoutes = () => {
  return (
    <Routes>
      <Route path="/" element={<Monitoring />} />
      <Route path="/inbound" element={<Inbound />} />
      <Route path="/inbound-master" element={<InboundMaster />} />
      <Route path="/outbound" element={<Outbound />} />
      <Route path="/outbound-master" element={<OutboundMaster />} />
      <Route path="/cycle-count" element={<CycleCount />} />
      <Route path="/adjust-stock" element={<AdjustStock />} />
      <Route path="/refill" element={<Refill />} />
      <Route path="/inspection-mold" element={<InspectionMold />} />
    </Routes>
  );
};

export default AutoStorageRoutes;
