import React, { useState, useEffect } from "react";
import { Row, Col, Button, Form, Input, Spin, Checkbox } from "antd";
import { PlusOutlined } from "@ant-design/icons";
import moment from "moment";
import "../../styles/autostorage.css";
import Tables from "../../components/Tables";
import DropdownActionTable from "../../components/dropdown/DropdownActionTable";
import DrawerAdd from "./components/DrawerAddInbound";
import DrawerDetail from "./components/DrawerDetail";
import axios from "axios";
import NotificationAPI from "../../components/NotificationAPI";
import calculateColumnWidth from "../../function/CalcWidth";
import ActionHeaderTable from "./components/ActionHeaderTableIRI";
import ModalImportExcel from "../../components/modal/ModalImportExcel";
import ActionFooterTable from "../../components/ActionFooterTable";



const InboundMaster = () => {
  const [openDrawer, setOpenDrawer] = useState(false);
  const [openDrawerDetail, setOpenDrawerDetail] = useState(false);
  const [openNotification, setOpenNotification] = useState(null);
  const [description, setDescription] = useState(null);
  const [loading, setLoading] = useState(true);
  const [dataInbound, setDataInbound] = useState([]);
  const [selectedRecord, setSelectedRecord] = useState(null);
  const [totalItem, setTotalItem] = useState(0);
  const [totalQty, setTotalQty] = useState(0);
  const [onProcessCount, setOnProcessCount] = useState(0);
  const [completedCount, setCompletedCount] = useState(0);
  const [searchText, setSearchText] = useState("");
  const [isModalImportExcelOpen, setIsModalImportExcelOpen] = useState(false);
  const [handleResetClick, setHandleResetClick] = useState(false);
  const [selectedRows, setSelectedRows] = useState([]); // State สำหรับเก็บ row ที่ถูกเลือก

  const showDrawer = () => setOpenDrawer(true);
  const onCloseDrawer = () => setOpenDrawer(false);
  const onCloseDrawerDetail = () => setOpenDrawerDetail(false);
  const [form] = Form.useForm();

  const handleSubmit = () => {
    const formValues = form.getFieldsValue();
    const formattedDate = formValues.DateCreated ? moment(formValues.DateCreated).format("YYYY-MM-DD") : null;
    console.log("Form submitted");
    console.log({ ...formValues, DateCreated: formattedDate });
  };

  const handleDetailClick = (record) => {
    setSelectedRecord(record);
    setOpenDrawerDetail(true);
  };

  const handleSearch = (e) => {
    setSearchText(e.target.value);
  };

  const filters = (dataSource, searchText) => {
    return dataSource.filter((item) =>
      Object.values(item).some((value) =>
        value ? value.toString().toLowerCase().includes(searchText.toLowerCase()) : false
      )
    );
  };

  const columns = [
    {
      title: "✓",
      dataIndex: "checkbox",
      key: "checkbox",
      width: "3%",
      align: "center",
      fixed: "left",
      render: (text, record) => (
        <Checkbox
          checked={selectedRows.includes(record.key)}
          onChange={(e) => {
            const checked = e.target.checked;
            setSelectedRows(
              checked
                ? [...selectedRows, record.key]
                : selectedRows.filter((key) => key !== record.key)
            );
          }}
        />
      ),
    },
    {
      title: "No.",
      dataIndex: "no",
      key: "no",
      width: "4%",
      align: "center",
      fixed: "left",
    },
    {
      title: "Mold Code",
      dataIndex: "moldCode",
      key: "moldCode",
      width: calculateColumnWidth("Mold Code"),
      sorter: (a, b) => a.moldCode.localeCompare(b.moldCode),
      fixed: "left",
      align: "center",
    },
    {
      title: "Mold Serial",
      dataIndex: "moldSerial",
      key: "moldSerial",
      width: calculateColumnWidth("Mold Serial"),
      sorter: (a, b) => a.moldSerial.localeCompare(b.moldSerial),
      fixed: "left",
      align: "center",
    },
    {
      title: "Task Status.",
      dataIndex: "taskStatus",
      key: "taskStatu",
      width: calculateColumnWidth("Task Status"),
      sorter: (a, b) => a.taskStatu.localeCompare(b.taskStatu),
      fixed: "left",
      align: "center",
    },
    {
      title: "Tray Position",
      dataIndex: "trayposiyion",
      key: "trayposiyion",
      width: calculateColumnWidth("Tray Position"),
      sorter: (a, b) => a.trayposiyion.localeCompare(b.trayposiyion),
      fixed: "left",
      align: "center",
    },
    {
      title: "Total Location",
      dataIndex: "totallocation",
      key: "totallocation",
      width: calculateColumnWidth("Total Location"),
      sorter: (a, b) => a.totallocation.localeCompare(b.totallocation),
      fixed: "left",
      align: "center",
    },
    // {
    //   title: "Lot No.",
    //   dataIndex: "moldLotNo",
    //   key: "moldLotNo",
    //   width: calculateColumnWidth("Mold Lot No."),
    //   sorter: (a, b) => a.moldLotNo.localeCompare(b.moldLotNo),
    //   fixed: "left",
    //   align: "center",
    // },
    // {
    //   title: "Transaction CD",
    //   dataIndex: "moldTransactionCD",
    //   key: "moldTransactionCD",
    //   width: calculateColumnWidth("Mold Transaction CD"),
    //   sorter: (a, b) => a.moldTransactionCD - b.moldTransactionCD,
    //   align: "center",
    // },
    // {
    //   title: "Emp No.",
    //   dataIndex: "empNo",
    //   key: "empNo",
    //   width: calculateColumnWidth("Emp No."),
    //   sorter: (a, b) => a.empNo - b.empNo,
    //   align: "center",
    // },
    // {
    //   title: "Work Station",
    //   dataIndex: "moldWorkStation",
    //   key: "moldWorkStation",
    //   width: calculateColumnWidth("Mold Work Station"),
    //   align: "center",
    // },
    // {
    //   title: "Sndrcv Plant No.",
    //   dataIndex: "moldSndrcvPlantNo",
    //   key: "moldSndrcvPlantNo",
    //   width: calculateColumnWidth("Mold Sndrcv Plant No."),
    //   sorter: (a, b) => a.moldSndrcvPlantNo.localeCompare(b.moldSndrcvPlantNo),
    //   align: "center",
    // },
    // {
    //   title: "Sndrcv Stock Type",
    //   dataIndex: "moldSndrcvStockType",
    //   key: "moldSndrcvStockType",
    //   width: calculateColumnWidth("Mold Sndrcv Stock Type"),
    //   sorter: (a, b) => a.moldSndrcvStockType.localeCompare(b.moldSndrcvStockType),
    //   align: "center",
    // },
    // {
    //   title: "Sndrcv Place No.",
    //   dataIndex: "moldSndrcvPlaceNo",
    //   key: "moldSndrcvPlaceNo",
    //   width: calculateColumnWidth("Mold Sndrcv Place No."),
    //   sorter: (a, b) => a.moldSndrcvPlaceNo.localeCompare(b.moldSndrcvPlaceNo),
    //   align: "center",
    // },
    // {
    //   title: "Sndrcv Transaction CD",
    //   dataIndex: "moldSndrcvTransactionCD",
    //   key: "moldSndrcvTransactionCD",
    //   width: calculateColumnWidth("Mold Sndrcv Transaction CD"),
    //   sorter: (a, b) => a.moldSndrcvTransactionCD - b.moldSndrcvTransactionCD,
    //   align: "center",
    // },
    // {
    //   title: "Status",
    //   dataIndex: "status",
    //   key: "status",
    //   width: "120px",
    //   sorter: (a, b) => a.status.localeCompare(b.status),
    //   align: "center",
    // },
    {
      title: "More",
      dataIndex: "more",
      key: "more",
      render: (text, record) => (
        <DropdownActionTable onDetailClick={handleDetailClick} record={record} />
      ),
      width: "60px",
      align: "center",
      fixed: "right",
    },
  ];

  const getInbound = async () => {
    try {
      const response = await axios.get(
        "http://localhost:1234/api/InboundItempDetail-requests"
      );
      const data = response.data.map((item, index) => ({
        id: item.IRI_IDInboundRequestItem,
        key: item.IRI_IDInboundRequestItem,
        no: (index + 1).toString(),
        InboundNo: item.InboundNo,
        moldCode: item.MoldCode,
        moldSerial: item.MoldSerial,
        taskStatus: item.TaskStatus,
        trayposiyion: item.TrayPosition,
        totalLocation: item.ToLocation,


        // moldTransactionCD: item.MoldTransactionCD,
        // empNo: item.EmpNo,
        // moldWorkStation: item.MoldWorkStation,
        // moldLotNo: item.MoldLotNo,
        // moldSndrcvPlantNo: item.MoldSndrcvPlantNo,
        // moldSndrcvStockType: item.MoldSndrcvStockType,
        // moldSndrcvPlaceNo: item.MoldSndrcvPlaceNo,
        // moldSndrcvTransactionCD: item.MoldSndrcvTransactionCD,
        // status: item.InboundItemStatus,
        more: <DropdownActionTable onDetailClick={handleDetailClick} record={item} />,
      }));

      setTotalItem(data.length);
      setTotalQty(data.reduce((acc, item) => acc + item.qty, 0));

      const onProcess = data.filter((item) => item.status === "On Process").length;
      const completed = data.filter((item) => item.status === "Completed").length;

      setOnProcessCount(onProcess);
      setCompletedCount(completed);

      setDataInbound(data);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    getInbound();
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      if (dataInbound.length > 0) {
        const checkNewData = async () => {
          const response = await axios.get("api/TaskInboundDetail-requests");
          const newData = response.data.filter(
            (item) => !dataInbound.some((data) => data.key === item.TI_ID)
          );

          if (newData.length > 0) {
            getInbound();
            setOpenNotification("info");
            setDescription("New data is added " + newData.length + " record");
          }
        };
        checkNewData();
      }
    }, 2000);

    return () => clearInterval(interval);
  }, [dataInbound]);

  useEffect(() => {
    setLoading(dataInbound.length === 0);
  }, [dataInbound]);

  const filteredData = filters(dataInbound, searchText);

  return (
    <>
      <div className="table-container">
        <div className="table-header">
          <ActionHeaderTable
            AddButton={showDrawer}
            setIsModalImportExcelOpen={setIsModalImportExcelOpen}
            handleResetClick={handleResetClick}
            setHandleResetClick={() => setHandleResetClick(false)}
          />
          <Row gutter={16} style={{ marginTop: "2px", display: "flex", justifyContent: "flex-end", alignItems: "center" }}>
            <Col span={3} xs={6} sm={8} md={8} lg={3} xl={3}>
              <div className="detail-input">
                <span>Item:</span>
                <strong>{totalItem}</strong>
              </div>
            </Col>

            <Col span={3} xs={6} sm={8} md={8} lg={3} xl={3}>
              <div className="detail-input">
                <span>On Process:</span>
                <strong>{onProcessCount}</strong>
              </div>
            </Col>

            <Col span={3} xs={6} sm={8} md={8} lg={3} xl={3}>
              <div className="detail-input">
                <span>Completed:</span>
                <strong>{completedCount}</strong>
              </div>
            </Col>
          </Row>
        </div>

        <section style={{ marginTop: "10px" }}>
          <Spin spinning={loading}>
            <Tables
              columns={columns}
              dataSource={filteredData}
              bordered
              scrollY={0.5}
              scrollX={"max-content"}
              maxHeight={"480px"}
            />
          </Spin>
        </section>

        <div className="action-footer-table">
          {/* <ActionFooterTable handleReset={() => setHandleResetClick(true)} /> */}
        </div>
      </div>

      <section>
        <NotificationAPI openNotification={openNotification} description={description} />
        <DrawerAdd open={openDrawer} onClose={onCloseDrawer} />
        <DrawerDetail open={openDrawerDetail} onClose={onCloseDrawerDetail} record={selectedRecord} />
      </section>

      <ModalImportExcel isModalOpen={isModalImportExcelOpen} setIsModalOpen={setIsModalImportExcelOpen} />
    </>
  );
};

export default InboundMaster;