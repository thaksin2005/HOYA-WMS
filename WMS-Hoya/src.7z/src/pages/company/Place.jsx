import React from "react";
import Tables from "../../components/Tables";
import DropdownActionTable from "../../components/dropdown/DropdownActionTable";
import ModalAddPlace from "../../components/modal/ModalAddPlace";
import "../../styles/global.css";
import { useState, useEffect } from "react";
import calculateColumnWidth from "../../function/CalcWidth";
import { Button, Input, Modal, message } from "antd";
import { CheckCircleOutlined, CloseCircleOutlined } from "@ant-design/icons";
import { Plus } from "lucide-react";
import filters from "../../function/FilterTable";
import axios from "axios";
import DrawerDetailPlace from "./components/DrawerDetailPlace";
// import ActionHeaderTable from "../../components/ActionHeaderTable"

const Place = () => {
  const [messageApi, messageContextHolder] = message.useMessage();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [dataSource, setDataSource] = useState([]);
  const [openDrawer, setOpenDrawer] = useState(false);
  const [selectedPlace, setSelectedPlace] = useState(null);
  const [addedPlace, setAddedPlace] = useState(false);
  const showModal = () => {
    setIsModalOpen(true);
  };

  const handleSearch = (e) => {
    setSearchText(e.target.value);
  };

  const handleDetailPlace = (record) => {
    setSelectedPlace(record);
    setOpenDrawer(true);
  };

  const handleDeletePlace = (record) => {
    console.log(record);
  };

  useEffect(() => {
    if (addedPlace) {
      messageApi.success("Place added successfully");
      getPlaceData();
      setAddedPlace(false);
    }
  }, [addedPlace]);

  const columns = [
    {
      title: "ID", // เพิ่มคอลัมน์ ID
      dataIndex: "id",
      width: "5%",
      align: "center",
    },
    {
      title: "Warehouse Name",
      dataIndex: "warehouseName",
      width: "20%",
      filters: filters(dataSource, "warehouseName"),
      onFilter: (value, record) => record.warehouseName === value,
      sorter: (a, b) =>
        a.warehouseName ? a.warehouseName.localeCompare(b.warehouseName) : 0,
    },

    {
      title: "Place Code",
      dataIndex: "placeCode",
      width: "10%",
      filters: filters(dataSource, "placeCode"),
      onFilter: (value, record) => record.placeCode === value,
      sorter: (a, b) => a.placeCode.localeCompare(b.placeCode),
    },

    {
      title: "Place Name",
      dataIndex: "placeName",
      width: "20%",
      filters: filters(dataSource, "placeName"),
      onFilter: (value, record) => record.placeName === value,
      sorter: (a, b) => a.placeName.localeCompare(b.placeName),
    },

    {
      title: "Place Is Auto Storage",
      dataIndex: "isAutoStorage",
      align: "center",
      width: "10%",
      filters: filters(dataSource, "isAutoStorage"),
      onFilter: (value, record) => record.isAutoStorage === value,
      sorter: (a, b) => a.isAutoStorage.localeCompare(b.isAutoStorage),
      render: (_, record) => (
        <center>
          <div className={`isAutoStorage ${record.isAutoStorage}`}>
            {record.isAutoStorage === true ? (
              <CheckCircleOutlined />
            ) : (
              <CloseCircleOutlined />
            )}
          </div>
        </center>
      ),
    },
    {
      title: "Place Is Active",
      dataIndex: "isActive",
      align: "center",
      width: "10%",
      render: (_, record) => (
        <center>
          <div className={`isActive ${record.isActive}`}>
            {record.isActive === true ? (
              <CheckCircleOutlined />
            ) : (
              <CloseCircleOutlined />
            )}
          </div>
        </center>
      ),
      filters: filters(dataSource, "isActive"),
      onFilter: (value, record) => record.isActive === value,
      sorter: (a, b) => a.isActive.localeCompare(b.isActive),
    },

    {
      title: "More",
      dataIndex: "action",
      width: "5%",
      align: "center",
      render: (text, record) => (
        <DropdownActionTable
          onDetailClick={() => handleDetailPlace(record)}
          record={record}
          onDeleteClick={() => handleDeletePlace(record)}
        />
      ),
    },
  ];

  const getPlaceData = async () => {
    const response = await axios.get(
      "http://localhost:1234/api/PlaceDetail-requests"
    );
    const data = response.data.map((item, index) => ({
      key: item.P_IDPlace,
      id: item.P_IDPlace,
      placeCode: item.P_Code,
      placeName: item.P_Name,
      warehouseName: item.W_Fullname,
      isAutoStorage: item.P_IsAutoStorage,
      isActive: item.P_IsActive,
    }));
    setDataSource(data);
  };

  useEffect(() => {
    getPlaceData();
  }, []);

  const filteredDataSource = dataSource
    .map((item) => ({
      ...item,
      placeCode: item.placeCode || "", // เปลี่ยน NULL เป็นช่องว่าง
      placeName: item.placeName || "", // เปลี่ยน NULL เป็นช่องว่าง
    }))
    .filter((item) =>
      Object.values(item).some((value) =>
        value.toString().toLowerCase().includes(searchText.toLowerCase())
      )
    );

  return (
    <div className="table-container">
      {messageContextHolder}
      <div className="table-header2">
        <Input
          placeholder="Search"
          style={{ width: "300px" }}
          value={searchText}
          onChange={handleSearch}
        />
        <Button
          type="primary"
          icon={<Plus size={16} />}
          onClick={showModal}
          style={{ display: "flex", alignItems: "center", gap: "6px" }}
        >
          New Place
        </Button>
        <ModalAddPlace
          isModalOpen={isModalOpen}
          setIsModalOpen={setIsModalOpen}
          addedPlace={setAddedPlace}
        />
        {/* <ActionHeaderTable AddButton={showModal} /> */}
      </div>
      <div className="table-content">
        <Tables
          columns={columns}
          dataSource={filteredDataSource}
          scrollY={0.5}
          bordered={true}
        />
      </div>
      <DrawerDetailPlace
        open={openDrawer}
        onClose={() => setOpenDrawer(false)}
        record={selectedPlace}
      />
    </div>
  );
};

export default Place;
