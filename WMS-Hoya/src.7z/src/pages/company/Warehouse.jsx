import React, { useEffect } from "react";
import Tables from "../../components/Tables";
import DropdownActionTable from "../../components/dropdown/DropdownActionTable";
import ModalAddWarehouse from "../../components/modal/ModalAddWarehouse";
import "../../styles/global.css";
import { useState } from "react";
import calculateColumnWidth from "../../function/CalcWidth";
import { Button, Input } from "antd";
import { Plus } from "lucide-react";
import { CheckCircleOutlined, CloseCircleOutlined } from "@ant-design/icons";
// import ActionHeaderTable from "../../components/ActionHeaderTable";
import filters from "../../function/FilterTable";
import axios from "axios";
import DrawerDetailWarehouse from "./components/DrawerDetailWarehouse";
const Warehouse = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [dataSource, setDataSource] = useState([]);
  const [openDrawer, setOpenDrawer] = useState(false);
  const [selectedWarehouse, setSelectedWarehouse] = useState(null);

  const showModal = () => {
    setIsModalOpen(true);
  };

  const handleSearch = (e) => {
    setSearchText(e.target.value);
  };

  const handleDetailWarehouse = (record) => {
    setSelectedWarehouse(record);
    setOpenDrawer(true);
  };

  const handleDeleteWarehouse = (record) => {
    console.log(record);
  };

  const columns = [
    
    {
      title: "#",
      dataIndex: "no",
      width: "60px",
      align: "center",
    },
    {
      title: "Factory Name",
      dataIndex: "factory",
      width: calculateColumnWidth("Factory Name "),
      filters: filters(dataSource, "factory"),
      onFilter: (value, record) => record.factory === value,
      sorter: (a, b) => a.factory.localeCompare(b.factory),
    },
    {
      title: "Factory Site",
      dataIndex: "site",
      align: "center",
      width: calculateColumnWidth("Factory Site"),
      filters: filters(dataSource, "site"),
      onFilter: (value, record) => record.site === value,
      sorter: (a, b) => a.site.localeCompare(b.site),
    },
    {
      title: "Warehouse Code",
      dataIndex: "warehouseCode",
      align: "center",
      width: calculateColumnWidth("Warehouse Code"),
      filters: filters(dataSource, "warehouseCode"),
      onFilter: (value, record) => record.warehouseCode=== value,
      sorter: (a, b) => a.warehouseCode.localeCompare(b.warehouseCode),
    },

    {
      title: "Warehouse Name",
      dataIndex: "warehouseName",
      align: "center",
      width: calculateColumnWidth("Warehouse Name"),
      filters: filters(dataSource, "warehouseName"),
      onFilter: (value, record) => record.warehouseName === value,
      sorter: (a, b) => a.warehouseName.localeCompare(b.warehouseName),
    },

    {
      title: "Warehouse Active",
      dataIndex: "warehouseActive",
      align: "center",
      width: calculateColumnWidth("Warehouse Active"),
      filters: filters(dataSource, "warehouseActive"),
      onFilter: (value, record) => record.warehouseActive === value,
      sorter: (a, b) => a.warehouseActive.localeCompare(b.warehouseActive),
      render: (_, record) => (
        <center>
          <div className={`isActive ${record.warehouseActive}`}>
            {record.warehouseActive === "true" ? (
              <CheckCircleOutlined />
            ) : (
              <CloseCircleOutlined />
            )}
          </div>
        </center>
      ),
    },

    {
      title: "Warehouse Remarks",
      dataIndex: "warehouseRemark",
      align: "center",
      width: calculateColumnWidth("Warehouse Remarks"),
      filters: filters(dataSource, "warehouseRemark"),
      onFilter: (value, record) => record.warehouseRemark === value,
      sorter: (a, b) => a.warehouseRemark.localeCompare(b.warehouseRemark),
    },

    {
      title: "Username",
      dataIndex: "uaFullName",
      align: "center",
      width: calculateColumnWidth("Username"),
      filters: filters(dataSource, "uaFullName"),
      onFilter: (value, record) => record.uaFullName === value,
      sorter: (a, b) => a.uaFullName.localeCompare(b.uaFullName),
    },
    // {
    //   title: "Created At",
    //   dataIndex: "createdAt",
    // },

    // {
    //   title: "Create By",
    //   dataIndex: "createBy",
    // },
    {
      title: "More",
      dataIndex: "action",
      width: "50px",
      align: "center",
      render: (text, record) => (
        <DropdownActionTable
          onDetailClick={() => handleDetailWarehouse(record)}
          record={record}
          onDeleteClick={() => handleDeleteWarehouse(record)}
        />
      ),
    },
  ];

  const getWarehouseData = async () => {
    try {
      const response = await axios.get(
        "http://localhost:1234/api/WarehouseDetail-requests"
      );
      const data = response.data;

      // ตั้งค่า dataSource ด้วยข้อมูลที่ได้รับมา
      setDataSource(
        data.map((item, index) => ({
          no: index + 1,
          id: item.W_IDWarehouse,
          key: index + 1,
          factory: item.F_Name,
          site: item.F_Site,
          warehouseName: item.W_Name,
          warehouseCode: item.W_Code,
          warehouseActive: item.W_IsActive ? "true" : "false",
          warehouseRemark: item.W_Remarks || "",
          uaCode: item.UA_Code,
          uaFullName: item.UA_Fullname,
        }))
      );
    } catch (error) {
      console.error("Error fetching warehouse data:", error);
    }
  };

  useEffect(() => {
    getWarehouseData();
  }, []);

  // ฟังก์ชันกรองค่า NULL และ undefined
  const filteredDataSource = dataSource
    .map((item) => {
      return Object.keys(item).reduce((acc, key) => {
        acc[key] =
          item[key] === null || item[key] === undefined ? "" : item[key];
        return acc;
      }, {});
    })
    .filter((item) =>
      Object.values(item).some((value) =>
        value.toString().toLowerCase().includes(searchText.toLowerCase())
      )
    );

  return (
    <div className="table-container">
      <div className="table-header2">
        <Input
          placeholder="Search"
          style={{ width: "300px" }}
          value={searchText}
          onChange={handleSearch}
        />
        <Button
          type="primary"
          icon={<Plus size={16} />}
          onClick={showModal}
          style={{ display: "flex", alignItems: "center", gap: "6px" }}
        >
          New Warehouse
        </Button>
        <ModalAddWarehouse
          isModalOpen={isModalOpen}
          setIsModalOpen={setIsModalOpen}
        />
        {/* <ActionHeaderTable AddButton={showModal} /> */}
      </div>
      <div className="table-content">
        <Tables
          columns={columns}
          dataSource={filteredDataSource}
          scrollY={0.5}
          bordered={true}
          responsive={true}
        />
      </div>
      <DrawerDetailWarehouse
        open={openDrawer}
        onClose={() => setOpenDrawer(false)}
        record={selectedWarehouse}
      />
    </div>
  );
};

export default Warehouse;
