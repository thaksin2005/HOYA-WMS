import React from "react";

const ProductionPlan = () => {
  return <div>ProductionPlan</div>;
};

export default ProductionPlan;
