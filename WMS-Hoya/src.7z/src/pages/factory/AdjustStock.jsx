import React from "react";

const AdjustStock = () => {
  return <div>AdjustStock</div>;
};

export default AdjustStock;
