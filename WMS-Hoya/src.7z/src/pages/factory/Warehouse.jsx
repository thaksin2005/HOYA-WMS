import React from "react";

const Warehouse = () => {
  return <div>Warehouse</div>;
};

export default Warehouse;
