import React from "react";

const Building = () => {
  return <div>Building</div>;
};

export default Building;
