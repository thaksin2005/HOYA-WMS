import Tables from "../../components/Tables";
import DropdownActionTable from "../../components/dropdown/DropdownActionTable";
import DrawerDetailLocation from "./components/DrawerDetailLocation";
import { Button, Input } from "antd";
import { Plus } from "lucide-react";
import ModalAddLocation from "../../components/modal/ModalAddLocation";
import "../../styles/global.css";
import { useState, useEffect } from "react";
import axios from "axios";
import { Spin } from "antd";

const Location = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [openDrawerDetail, setOpenDrawerDetail] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [locationData, setLocationData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedRecord, setSelectedRecord] = useState(null);

  const showModal = () => {
    setIsModalOpen(true);
  };

  const handleSearch = (e) => {
    setSearchText(e.target.value);
  };

  const onCloseDrawerDetail = () => {
    setOpenDrawerDetail(false);
  };

  const handleDetailClick = (record) => {
    setSelectedRecord(record);
    setOpenDrawerDetail(true);
  };

  const columns = [
    {
      title: "No.",
      dataIndex: "no",
      width: "60px",
      align: "center",
      fixed: "left",
    },
    {
      title: "Factory Code",
      dataIndex: "F_Code",
      width: `${"Factory Code".length * 10}px`,
    },
    {
      title: "City",
      dataIndex: "F_City",
    },
    {
      title: "Warehouse Code",
      dataIndex: "W_Code",
      width: `${"Warehouse Code".length * 10}px`,
    },

    {
      title: "Warehouse Name",
      dataIndex: "W_Name",
      width: `${"Warehouse Name".length * 12}px`,
    },

    {
      title: "Place Code",
      dataIndex: "P_Code",
      width: `${"Place Code".length * 10}px`,
    },
    {
      title: "Location Code",
      dataIndex: "L_Code",
    },
    {
      title: "Tray Number",
      dataIndex: "T_Number",
      width: `${"Tray Number".length * 18}px`,
    },

    {
      title: "Tray Status",
      dataIndex: "T_Status",
    },
    {
      title: "More",
      dataIndex: "more",
      width: "80px",
      align: "center",
      fixed: "right",
      key: "more",
      render: (text, record) => (
        <DropdownActionTable
          onDetailClick={handleDetailClick}
          record={record}
        />
      ),
    },
  ];

  const getLocation = async () => {
    try {
      setLoading(true);
      const response = await axios.get("/api/LocationDetail-requests");
      const data = response.data.map((item, index) => ({
        key: item.L_IDLocation,
        no: (index + 1).toString(),
        F_IDFactory: item.F_IDFactory,
        F_Code: item.F_Code,
        F_Name: item.F_Name,
        F_City: item.F_City,
        W_Code: item.W_Code,
        W_Name: item.W_Name,
        P_Code: item.P_Code,
        P_Name: item.P_Name,
        L_Code: item.L_Code,
        L_Description: item.L_Description,
        T_Number: item.T_Number,
        T_Status: item.T_Status,
        F_ShortCode: item.F_ShortCode,
        F_Site: item.F_Site,
        F_IsActive: item.F_IsActive,
        W_IDWarehouse: item.W_IDWarehouse,
        W_IsActive: item.W_IsActive,
        P_IDPlace: item.P_IDPlace,
        P_IsAutoStorage: item.P_IsAutoStorage,
        L_VZone: item.L_VZone,
        L_HZone: item.L_HZone,
        L_IsActive: item.L_IsActive,
        L_IsBlock: item.L_IsBlock,
        L_IsReserve: item.L_IsReserve,
        S_IDStacker: item.S_IDStacker,
        S_Code: item.S_Code,
        S_Name: item.S_Name,
        S_IsActive: item.S_IsActive,
        T_IDTray: item.T_IDTray,
        more: <DropdownActionTable />,
      }));
      setLocationData(data);
    } catch (error) {
      // console.error("Error fetching location data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    getLocation();
  }, []);

  const filteredLocationData = locationData.filter((item) =>
    Object.values(item).some((value) =>
      value.toString().toLowerCase().includes(searchText.toLowerCase())
    )
  );

  return (
    <>
      <Spin spinning={loading}>
        <div className="table-container">
          <div className="table-header">
            <Input
              placeholder="Search"
              style={{ width: "300px" }}
              value={searchText}
              onChange={handleSearch}
            />
            <Button
              type="primary"
              icon={<Plus size={16} />}
              onClick={showModal}
              style={{ display: "flex", alignItems: "center", gap: "6px" }}
            >
              New Location
            </Button>
            <ModalAddLocation
              isModalOpen={isModalOpen}
              setIsModalOpen={setIsModalOpen}
            />
          </div>
          <div className="table-content">
            <Tables
              columns={columns}
              dataSource={filteredLocationData}
              scrollY={0.6}
              scrollX={"max-content"}
              bordered={true}
            />
          </div>
        </div>

        <section>
          <DrawerDetailLocation
            open={openDrawerDetail}
            onClose={onCloseDrawerDetail}
            record={selectedRecord}
          />
        </section>
      </Spin>
    </>
  );
};

export default Location;
