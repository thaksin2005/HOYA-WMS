export const testUser = [
  {
    username: "admin",
    password: "admin",
    role: "admin",
  },
  {
    username: "admin2",
    password: "admin2",
    role: "admin",
  },
  {
    username: "user",
    password: "user",
    role: "user",
  },
];
