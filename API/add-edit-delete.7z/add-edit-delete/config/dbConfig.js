// config/dbConfig.js
require("dotenv").config();
const sql = require("mssql");

const config = {
    user: process.env.DB_USER, // ชื่อผู้ใช้
    password: process.env.DB_PASSWORD, // รหัสผ่าน
    server: process.env.DB_SERVER, // ชื่อเซิร์ฟเวอร์
    database: process.env.DB_NAME, // ชื่อฐานข้อมูล
    options: {
        encrypt: false, // ตั้งค่าให้เป็น true ถ้าใช้ Azure
        trustServerCertificate: true, // การรับรองใบรับรอง
    },
};

const poolPromise = new sql.ConnectionPool(config)
    .connect()
    .then((pool) => {
        console.log("Connected to MSSQL");
        return pool;
    })
    .catch((err) => {
        console.log("Database Connection Failed! ", err);
        throw err;
    });

module.exports = { sql, poolPromise };